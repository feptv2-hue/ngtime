package com.example.hhh.game.config

import android.graphics.Paint
import android.graphics.Color

object HudConfig {
    // Настройки HUD
    val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 40f
        isAntiAlias = true
    }

    val backgroundPaint = Paint().apply {
        color = Color.argb(180, 0, 0, 0)
    }

    // Позиции элементов HUD (в процентах от экрана)
    const val SCORE_X_RATIO = 0.05f
    const val SCORE_Y_RATIO = 0.05f
    const val LIVES_X_RATIO = 0.85f
    const val LIVES_Y_RATIO = 0.05f
}