// com/example/hhh/game/config/UnitsConfig.kt
package com.example.hhh.game.config

object UnitsConfig {
    // === РОССИЯ - НАЗЕМНЫЕ ===
    // com/example/hhh/game/config/UnitsConfig.kt

    val russiaGroundMbt = listOf(
        UnitData(
            id = "rus_mbt_1",
            name = "Т-72Б3",
            nation = "РОССИЯ",
            type = UnitType.GROUND,
            classType = UnitClass.MBT,
            tier = 1,
            icon = "tank_icon",
            textureCorpus = "textures/units/russia/t72/corpus.png",
            textureTurret = "textures/units/russia/t72/turret.png",
            // 🔥 РАЗМЕР НА КАРТЕ (НЕ ТЕКСТУРЫ!)
            width = 64f,          // 2 тайла (32 * 2)
            height = 48f,         // 1.5 тайла (32 * 1.5)
            speed = 120f,
            rotationSpeed = 180f,
            hitboxWidth = 56f,
            hitboxHeight = 40f,
            // 🔥 ТОЧКИ ДЛЯ ТЕКСТУРЫ
            pivotX = 131f,        // центр башни в текстуре корпуса (X)
            pivotY = 61f,         // центр башни в текстуре корпуса (Y)
            turretOffsetX = 0f,   // башня накладывается на pivot корпуса
            turretOffsetY = 0f,   // башня накладывается на pivot корпуса
            turretPivotX = 68f,   // центр башни в текстуре башни (X)
            turretPivotY = 62f,   // центр башни в текстуре башни (Y)
            turretWidth = 128f,   // размер башни на карте (пикселей)
            turretHeight = 128f   // размер башни на карте (пикселей)
        )
    )

    val russiaGroundIfv = listOf(
        UnitData(
            id = "rus_ifv_1",
            name = "БМП-2",
            nation = "РОССИЯ",
            type = UnitType.GROUND,
            classType = UnitClass.IFV,
            tier = 1,
            icon = "ifv_icon",
            textureCorpus = "bmp2_corpus",
            textureTurret = "bmp2_turret",
            width = 56f,
            height = 40f,
            speed = 130f,
            rotationSpeed = 200f,
            hitboxWidth = 50f,
            hitboxHeight = 36f,
            pivotX = 28f,
            pivotY = 20f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 16f,
            turretPivotY = 16f,
            turretWidth = 32f,
            turretHeight = 32f
        )
    )

    val russiaGroundSpg = listOf(
        UnitData(
            id = "rus_spg_1",
            name = "2С1 Гвоздика",
            nation = "РОССИЯ",
            type = UnitType.GROUND,
            classType = UnitClass.SPG,
            tier = 1,
            icon = "spg_icon",
            textureCorpus = "gvozdika_corpus",
            textureTurret = "gvozdika_turret",
            width = 60f,
            height = 44f,
            speed = 100f,
            rotationSpeed = 150f,
            hitboxWidth = 52f,
            hitboxHeight = 38f,
            pivotX = 30f,
            pivotY = 22f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 16f,
            turretPivotY = 16f,
            turretWidth = 32f,
            turretHeight = 32f
        )
    )

    val russiaGroundAa = listOf(
        UnitData(
            id = "rus_aa_1",
            name = "ЗСУ-23-4 Шилка",
            nation = "РОССИЯ",
            type = UnitType.GROUND,
            classType = UnitClass.AA,
            tier = 1,
            icon = "aa_icon",
            textureCorpus = "shilka_corpus",
            textureTurret = "shilka_turret",
            width = 56f,
            height = 40f,
            speed = 110f,
            rotationSpeed = 190f,
            hitboxWidth = 48f,
            hitboxHeight = 36f,
            pivotX = 28f,
            pivotY = 20f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 16f,
            turretPivotY = 16f,
            turretWidth = 32f,
            turretHeight = 32f
        )
    )

    // === РОССИЯ - ПЕХОТА ===
    val russiaInfantryRifle = listOf(
        UnitData(
            id = "rus_rifle_1",
            name = "Мотострелки",
            nation = "РОССИЯ",
            type = UnitType.INFANTRY,
            classType = UnitClass.RIFLE,
            tier = 1,
            icon = "inf_icon",
            textureCorpus = "infantry",
            textureTurret = "",
            width = 24f,
            height = 24f,
            speed = 80f,
            rotationSpeed = 360f,
            hitboxWidth = 20f,
            hitboxHeight = 20f,
            pivotX = 12f,
            pivotY = 12f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val russiaInfantrySpecial = listOf(
        UnitData(
            id = "rus_spec_1",
            name = "Спецназ ГРУ",
            nation = "РОССИЯ",
            type = UnitType.INFANTRY,
            classType = UnitClass.SPECIAL,
            tier = 1,
            icon = "spec_icon",
            textureCorpus = "specnaz",
            textureTurret = "",
            width = 24f,
            height = 24f,
            speed = 90f,
            rotationSpeed = 360f,
            hitboxWidth = 20f,
            hitboxHeight = 20f,
            pivotX = 12f,
            pivotY = 12f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val russiaInfantryAt = listOf(
        UnitData(
            id = "rus_at_1",
            name = "Гранатометчики",
            nation = "РОССИЯ",
            type = UnitType.INFANTRY,
            classType = UnitClass.AT,
            tier = 1,
            icon = "at_icon",
            textureCorpus = "at_infantry",
            textureTurret = "",
            width = 24f,
            height = 24f,
            speed = 75f,
            rotationSpeed = 360f,
            hitboxWidth = 20f,
            hitboxHeight = 20f,
            pivotX = 12f,
            pivotY = 12f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    // === РОССИЯ - АВИАЦИЯ ===
    val russiaAviationFighter = listOf(
        UnitData(
            id = "rus_fighter_1",
            name = "МиГ-29",
            nation = "РОССИЯ",
            type = UnitType.AVIATION,
            classType = UnitClass.FIGHTER,
            tier = 1,
            icon = "fighter_icon",
            textureCorpus = "mig29",
            textureTurret = "",
            width = 80f,
            height = 56f,
            speed = 400f,
            rotationSpeed = 250f,
            hitboxWidth = 72f,
            hitboxHeight = 48f,
            pivotX = 40f,
            pivotY = 28f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val russiaAviationAttack = listOf(
        UnitData(
            id = "rus_attack_1",
            name = "Су-25",
            nation = "РОССИЯ",
            type = UnitType.AVIATION,
            classType = UnitClass.ATTACK,
            tier = 1,
            icon = "attack_icon",
            textureCorpus = "su25",
            textureTurret = "",
            width = 76f,
            height = 52f,
            speed = 350f,
            rotationSpeed = 220f,
            hitboxWidth = 68f,
            hitboxHeight = 44f,
            pivotX = 38f,
            pivotY = 26f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val russiaAviationHelicopter = listOf(
        UnitData(
            id = "rus_helo_1",
            name = "Ми-24",
            nation = "РОССИЯ",
            type = UnitType.AVIATION,
            classType = UnitClass.HELICOPTER,
            tier = 1,
            icon = "helo_icon",
            textureCorpus = "mi24",
            textureTurret = "",
            width = 64f,
            height = 48f,
            speed = 280f,
            rotationSpeed = 300f,
            hitboxWidth = 56f,
            hitboxHeight = 40f,
            pivotX = 32f,
            pivotY = 24f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    // === США - НАЗЕМНЫЕ ===
    val usGroundMbt = listOf(
        UnitData(
            id = "us_mbt_1",
            name = "M1 Abrams",
            nation = "США",
            type = UnitType.GROUND,
            classType = UnitClass.MBT,
            tier = 1,
            icon = "tank_icon",
            textureCorpus = "abrams_corpus",
            textureTurret = "abrams_turret",
            width = 66f,
            height = 48f,
            speed = 125f,
            rotationSpeed = 185f,
            hitboxWidth = 58f,
            hitboxHeight = 42f,
            pivotX = 33f,
            pivotY = 24f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 16f,
            turretPivotY = 16f,
            turretWidth = 32f,
            turretHeight = 32f
        )
    )

    val usGroundIfv = listOf(
        UnitData(
            id = "us_ifv_1",
            name = "M2 Bradley",
            nation = "США",
            type = UnitType.GROUND,
            classType = UnitClass.IFV,
            tier = 1,
            icon = "ifv_icon",
            textureCorpus = "bradley_corpus",
            textureTurret = "bradley_turret",
            width = 56f,
            height = 40f,
            speed = 130f,
            rotationSpeed = 200f,
            hitboxWidth = 50f,
            hitboxHeight = 36f,
            pivotX = 28f,
            pivotY = 20f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 16f,
            turretPivotY = 16f,
            turretWidth = 32f,
            turretHeight = 32f
        )
    )

    val usGroundSpg = listOf(
        UnitData(
            id = "us_spg_1",
            name = "M109 Paladin",
            nation = "США",
            type = UnitType.GROUND,
            classType = UnitClass.SPG,
            tier = 1,
            icon = "spg_icon",
            textureCorpus = "paladin_corpus",
            textureTurret = "paladin_turret",
            width = 60f,
            height = 44f,
            speed = 100f,
            rotationSpeed = 150f,
            hitboxWidth = 52f,
            hitboxHeight = 38f,
            pivotX = 30f,
            pivotY = 22f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 16f,
            turretPivotY = 16f,
            turretWidth = 32f,
            turretHeight = 32f
        )
    )

    val usGroundAa = listOf(
        UnitData(
            id = "us_aa_1",
            name = "M163 VADS",
            nation = "США",
            type = UnitType.GROUND,
            classType = UnitClass.AA,
            tier = 1,
            icon = "aa_icon",
            textureCorpus = "vads_corpus",
            textureTurret = "vads_turret",
            width = 54f,
            height = 38f,
            speed = 110f,
            rotationSpeed = 190f,
            hitboxWidth = 46f,
            hitboxHeight = 34f,
            pivotX = 27f,
            pivotY = 19f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 16f,
            turretPivotY = 16f,
            turretWidth = 32f,
            turretHeight = 32f
        )
    )

    // === США - ПЕХОТА ===
    val usInfantryRifle = listOf(
        UnitData(
            id = "us_rifle_1",
            name = "Пехота США",
            nation = "США",
            type = UnitType.INFANTRY,
            classType = UnitClass.RIFLE,
            tier = 1,
            icon = "inf_icon",
            textureCorpus = "us_infantry",
            textureTurret = "",
            width = 24f,
            height = 24f,
            speed = 80f,
            rotationSpeed = 360f,
            hitboxWidth = 20f,
            hitboxHeight = 20f,
            pivotX = 12f,
            pivotY = 12f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val usInfantrySpecial = listOf(
        UnitData(
            id = "us_spec_1",
            name = "Delta Force",
            nation = "США",
            type = UnitType.INFANTRY,
            classType = UnitClass.SPECIAL,
            tier = 1,
            icon = "spec_icon",
            textureCorpus = "delta_force",
            textureTurret = "",
            width = 24f,
            height = 24f,
            speed = 90f,
            rotationSpeed = 360f,
            hitboxWidth = 20f,
            hitboxHeight = 20f,
            pivotX = 12f,
            pivotY = 12f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val usInfantryAt = listOf(
        UnitData(
            id = "us_at_1",
            name = "Javelin Team",
            nation = "США",
            type = UnitType.INFANTRY,
            classType = UnitClass.AT,
            tier = 1,
            icon = "at_icon",
            textureCorpus = "javelin",
            textureTurret = "",
            width = 24f,
            height = 24f,
            speed = 75f,
            rotationSpeed = 360f,
            hitboxWidth = 20f,
            hitboxHeight = 20f,
            pivotX = 12f,
            pivotY = 12f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    // === США - АВИАЦИЯ ===
    val usAviationFighter = listOf(
        UnitData(
            id = "us_fighter_1",
            name = "F-16 Falcon",
            nation = "США",
            type = UnitType.AVIATION,
            classType = UnitClass.FIGHTER,
            tier = 1,
            icon = "fighter_icon",
            textureCorpus = "f16",
            textureTurret = "",
            width = 80f,
            height = 56f,
            speed = 420f,
            rotationSpeed = 260f,
            hitboxWidth = 72f,
            hitboxHeight = 48f,
            pivotX = 40f,
            pivotY = 28f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val usAviationAttack = listOf(
        UnitData(
            id = "us_attack_1",
            name = "A-10 Warthog",
            nation = "США",
            type = UnitType.AVIATION,
            classType = UnitClass.ATTACK,
            tier = 1,
            icon = "attack_icon",
            textureCorpus = "a10",
            textureTurret = "",
            width = 76f,
            height = 52f,
            speed = 330f,
            rotationSpeed = 210f,
            hitboxWidth = 68f,
            hitboxHeight = 44f,
            pivotX = 38f,
            pivotY = 26f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val usAviationHelicopter = listOf(
        UnitData(
            id = "us_helo_1",
            name = "AH-64 Apache",
            nation = "США",
            type = UnitType.AVIATION,
            classType = UnitClass.HELICOPTER,
            tier = 1,
            icon = "helo_icon",
            textureCorpus = "apache",
            textureTurret = "",
            width = 64f,
            height = 48f,
            speed = 290f,
            rotationSpeed = 310f,
            hitboxWidth = 56f,
            hitboxHeight = 40f,
            pivotX = 32f,
            pivotY = 24f,
            turretOffsetX = 0f,
            turretOffsetY = 0f,
            turretPivotX = 0f,
            turretPivotY = 0f,
            turretWidth = 0f,
            turretHeight = 0f
        )
    )

    val allUnits = listOf(
        *russiaGroundMbt.toTypedArray(),
        *russiaGroundIfv.toTypedArray(),
        *russiaGroundSpg.toTypedArray(),
        *russiaGroundAa.toTypedArray(),
        *russiaInfantryRifle.toTypedArray(),
        *russiaInfantrySpecial.toTypedArray(),
        *russiaInfantryAt.toTypedArray(),
        *russiaAviationFighter.toTypedArray(),
        *russiaAviationAttack.toTypedArray(),
        *russiaAviationHelicopter.toTypedArray(),
        *usGroundMbt.toTypedArray(),
        *usGroundIfv.toTypedArray(),
        *usGroundSpg.toTypedArray(),
        *usGroundAa.toTypedArray(),
        *usInfantryRifle.toTypedArray(),
        *usInfantrySpecial.toTypedArray(),
        *usInfantryAt.toTypedArray(),
        *usAviationFighter.toTypedArray(),
        *usAviationAttack.toTypedArray(),
        *usAviationHelicopter.toTypedArray()
    )

    fun getUnitTypes(nation: String): List<UnitType> {
        return allUnits.filter { it.nation == nation }.map { it.type }.distinct()
    }

    fun getUnits(nation: String, type: UnitType): List<UnitData> {
        return allUnits.filter { it.nation == nation && it.type == type }
    }

    fun getUnitClasses(nation: String, type: UnitType): List<UnitClass> {
        return allUnits.filter { it.nation == nation && it.type == type }
            .map { it.classType }
            .distinct()
    }

    fun getUnitsByClass(nation: String, type: UnitType, classType: UnitClass): List<UnitData> {
        return allUnits.filter { it.nation == nation && it.type == type && it.classType == classType }
    }

    fun getClassName(classType: UnitClass): String {
        return when (classType) {
            UnitClass.MBT -> "ОСНОВНЫЕ ТАНКИ"
            UnitClass.IFV -> "БМП"
            UnitClass.SPG -> "САУ"
            UnitClass.AA -> "ЗСУ/ПВО"
            UnitClass.RIFLE -> "СТРЕЛКИ"
            UnitClass.SPECIAL -> "СПЕЦНАЗ"
            UnitClass.AT -> "ПТРК"
            UnitClass.FIGHTER -> "ИСТРЕБИТЕЛИ"
            UnitClass.ATTACK -> "ШТУРМОВИКИ"
            UnitClass.HELICOPTER -> "ВЕРТОЛЕТЫ"
        }
    }
}