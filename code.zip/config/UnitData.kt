// com/example/hhh/game/config/UnitData.kt
package com.example.hhh.game.config

// 🔥 ЭТИ ENUM'ы ДОЛЖНЫ БЫТЬ ЗДЕСЬ
enum class UnitType {
    GROUND,
    INFANTRY,
    AVIATION
}

enum class UnitClass {
    MBT, IFV, SPG, AA,
    RIFLE, SPECIAL, AT,
    FIGHTER, ATTACK, HELICOPTER
}

data class UnitData(
    val id: String,
    val name: String,
    val nation: String,
    val type: UnitType,
    val classType: UnitClass,
    val tier: Int,
    val icon: String,
    val textureCorpus: String,
    val textureTurret: String,
    val width: Float,
    val height: Float,
    val speed: Float,
    val rotationSpeed: Float,
    val hitboxWidth: Float,
    val hitboxHeight: Float,
    // Позиционирование
    val pivotX: Float = width / 2f,
    val pivotY: Float = height / 2f,
    val turretOffsetX: Float = 0f,
    val turretOffsetY: Float = 0f,
    val turretPivotX: Float = 64f,
    val turretPivotY: Float = 64f,
    val turretWidth: Float = 128f,
    val turretHeight: Float = 128f
)