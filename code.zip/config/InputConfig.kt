package com.example.hhh.game.config

object InputConfig {
    // Зоны для Touch-ввода
    const val LEFT_ZONE_RATIO = 0.3f   // Левая треть экрана
    const val RIGHT_ZONE_RATIO = 0.7f  // Правая треть экрана

    // Минимальное расстояние для свайпа
    const val MIN_SWIPE_DISTANCE = 50f

    // Время для определения клика
    const val MAX_TAP_DURATION = 200L // мс
}