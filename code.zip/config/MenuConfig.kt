package com.example.hhh.game.config

import android.graphics.Color

object MenuConfig {
    // Цвета как в War Thunder
    val BACKGROUND_TOP = Color.parseColor("#1a2233")
    val BACKGROUND_BOTTOM = Color.parseColor("#3a4050")

    // Горизонтальные полосы
    val TOP_BAR_COLOR = Color.parseColor("#3a4050")
    val BOTTOM_BAR_COLOR = Color.parseColor("#2a3545")  // Темнее для нижней панели
    val BAR_TEXT_COLOR = Color.parseColor("#8a9aaa")
    val TEXT_PRIMARY = Color.WHITE

    // Кнопки
    val BUTTON_PLAY_COLOR = Color.parseColor("#4CAF50")
    val BUTTON_PLAY_TEXT = Color.WHITE

    val BUTTON_MODE_COLOR = Color.parseColor("#3a4050")
    val BUTTON_MODE_SELECTED = Color.parseColor("#4a5a6a")
    val BUTTON_MODE_TEXT = Color.parseColor("#8a9aaa")
    val BUTTON_MODE_TEXT_SELECTED = Color.WHITE

    // Нижняя панель (сетапы)
    val SETUP_PANEL_COLOR = Color.parseColor("#2a3545")
    val SETUP_SLOT_COLOR = Color.parseColor("#1a2233")
    val SETUP_SLOT_BORDER = Color.parseColor("#4a5a6a")
    val SETUP_SLOT_EMPTY = Color.parseColor("#3a4050")
    val SETUP_TEXT_COLOR = Color.parseColor("#6a7a8a")

    // Кнопки наций
    val NATION_BUTTON_COLOR = Color.parseColor("#3a4050")
    val NATION_BUTTON_SELECTED = Color.parseColor("#4a5a6a")
    val NATION_BUTTON_TEXT = Color.parseColor("#8a9aaa")
    val NATION_BUTTON_TEXT_SELECTED = Color.WHITE

    val BORDER_COLOR = Color.parseColor("#4a5a6a")

    // Размеры
    const val BUTTON_WIDTH_RATIO = 0.4f
    const val BUTTON_PLAY_HEIGHT_RATIO = 0.08f
    const val BAR_HEIGHT_RATIO = 0.05f
    const val SETUP_PANEL_HEIGHT_RATIO = 0.25f  // Высота нижней панели

    // Загрузка
    const val LOADING_TEXT = "ЗАГРУЗКА"
    const val LOADING_DELAY_MS = 500L
    const val MIN_LOADING_TIME_MS = 2000L
}