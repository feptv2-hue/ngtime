package com.example.hhh.game.config

data class UnitStats(
    val id: String,
    val name: String,
    val nation: String,
    val type: UnitType,
    val classType: UnitClass,
    val tier: Int,
    val icon: String,
    val firepower: Int,
    val armor: Int,
    val mobility: Int,
    val range: Int,
    val accuracy: Int,
    val weapons: List<WeaponType>
)

enum class WeaponType {
    CANNON, ATGM, MACHINE_GUN, ROCKET, GRENADE,
    RIFLE, SNIPER_RIFLE, RPG, PISTOL,
    MISSILE, BOMB, CANNON_AIR, ROCKET_AIR
}

object UnitStatsConfig {
    private val statsMap = mapOf(
        // Россия - Наземные
        "rus_mbt_1" to UnitStats(
            "rus_mbt_1", "Т-72Б3", "РОССИЯ", UnitType.GROUND, UnitClass.MBT, 1,
            "tank_icon", 75, 80, 65, 60, 70,
            listOf(WeaponType.CANNON, WeaponType.MACHINE_GUN)
        ),
        "rus_ifv_1" to UnitStats(
            "rus_ifv_1", "БМП-2", "РОССИЯ", UnitType.GROUND, UnitClass.IFV, 1,
            "ifv_icon", 60, 50, 75, 55, 65,
            listOf(WeaponType.CANNON, WeaponType.ATGM)
        ),
        "rus_spg_1" to UnitStats(
            "rus_spg_1", "2С1 Гвоздика", "РОССИЯ", UnitType.GROUND, UnitClass.SPG, 1,
            "spg_icon", 85, 30, 50, 90, 60,
            listOf(WeaponType.CANNON)
        ),
        "rus_aa_1" to UnitStats(
            "rus_aa_1", "ЗСУ-23-4 Шилка", "РОССИЯ", UnitType.GROUND, UnitClass.AA, 1,
            "aa_icon", 70, 40, 60, 70, 80,
            listOf(WeaponType.CANNON, WeaponType.MACHINE_GUN)
        ),
        // Россия - Пехота
        "rus_rifle_1" to UnitStats(
            "rus_rifle_1", "Мотострелки", "РОССИЯ", UnitType.INFANTRY, UnitClass.RIFLE, 1,
            "inf_icon", 50, 30, 60, 40, 70,
            listOf(WeaponType.RIFLE, WeaponType.GRENADE)
        ),
        "rus_spec_1" to UnitStats(
            "rus_spec_1", "Спецназ ГРУ", "РОССИЯ", UnitType.INFANTRY, UnitClass.SPECIAL, 1,
            "spec_icon", 70, 40, 80, 50, 85,
            listOf(WeaponType.RIFLE, WeaponType.SNIPER_RIFLE, WeaponType.GRENADE)
        ),
        "rus_at_1" to UnitStats(
            "rus_at_1", "Гранатометчики", "РОССИЯ", UnitType.INFANTRY, UnitClass.AT, 1,
            "at_icon", 80, 30, 50, 70, 70,
            listOf(WeaponType.RPG, WeaponType.PISTOL)
        ),
        // Россия - Авиация
        "rus_fighter_1" to UnitStats(
            "rus_fighter_1", "МиГ-29", "РОССИЯ", UnitType.AVIATION, UnitClass.FIGHTER, 1,
            "fighter_icon", 85, 60, 90, 75, 80,
            listOf(WeaponType.MISSILE, WeaponType.CANNON_AIR)
        ),
        "rus_attack_1" to UnitStats(
            "rus_attack_1", "Су-25", "РОССИЯ", UnitType.AVIATION, UnitClass.ATTACK, 1,
            "attack_icon", 90, 70, 70, 80, 75,
            listOf(WeaponType.ROCKET_AIR, WeaponType.BOMB, WeaponType.CANNON_AIR)
        ),
        "rus_helo_1" to UnitStats(
            "rus_helo_1", "Ми-24", "РОССИЯ", UnitType.AVIATION, UnitClass.HELICOPTER, 1,
            "helo_icon", 75, 50, 70, 70, 70,
            listOf(WeaponType.ROCKET_AIR, WeaponType.ATGM, WeaponType.MACHINE_GUN)
        ),
        // США - Наземные
        "us_mbt_1" to UnitStats(
            "us_mbt_1", "M1 Abrams", "США", UnitType.GROUND, UnitClass.MBT, 1,
            "tank_icon", 80, 85, 70, 65, 75,
            listOf(WeaponType.CANNON, WeaponType.MACHINE_GUN)
        ),
        "us_ifv_1" to UnitStats(
            "us_ifv_1", "M2 Bradley", "США", UnitType.GROUND, UnitClass.IFV, 1,
            "ifv_icon", 60, 50, 75, 55, 65,
            listOf(WeaponType.CANNON, WeaponType.ATGM)
        ),
        "us_spg_1" to UnitStats(
            "us_spg_1", "M109 Paladin", "США", UnitType.GROUND, UnitClass.SPG, 1,
            "spg_icon", 80, 30, 50, 85, 60,
            listOf(WeaponType.CANNON)
        ),
        "us_aa_1" to UnitStats(
            "us_aa_1", "M163 VADS", "США", UnitType.GROUND, UnitClass.AA, 1,
            "aa_icon", 65, 35, 60, 65, 75,
            listOf(WeaponType.CANNON, WeaponType.MACHINE_GUN)
        ),
        // США - Пехота
        "us_rifle_1" to UnitStats(
            "us_rifle_1", "Пехота США", "США", UnitType.INFANTRY, UnitClass.RIFLE, 1,
            "inf_icon", 55, 30, 60, 40, 70,
            listOf(WeaponType.RIFLE, WeaponType.GRENADE)
        ),
        "us_spec_1" to UnitStats(
            "us_spec_1", "Delta Force", "США", UnitType.INFANTRY, UnitClass.SPECIAL, 1,
            "spec_icon", 75, 40, 80, 50, 85,
            listOf(WeaponType.RIFLE, WeaponType.SNIPER_RIFLE, WeaponType.PISTOL)
        ),
        "us_at_1" to UnitStats(
            "us_at_1", "Javelin Team", "США", UnitType.INFANTRY, UnitClass.AT, 1,
            "at_icon", 85, 30, 50, 75, 75,
            listOf(WeaponType.RPG, WeaponType.PISTOL)
        ),
        // США - Авиация
        "us_fighter_1" to UnitStats(
            "us_fighter_1", "F-16 Falcon", "США", UnitType.AVIATION, UnitClass.FIGHTER, 1,
            "fighter_icon", 85, 60, 90, 75, 80,
            listOf(WeaponType.MISSILE, WeaponType.CANNON_AIR)
        ),
        "us_attack_1" to UnitStats(
            "us_attack_1", "A-10 Warthog", "США", UnitType.AVIATION, UnitClass.ATTACK, 1,
            "attack_icon", 95, 75, 65, 80, 85,
            listOf(WeaponType.CANNON_AIR, WeaponType.ROCKET_AIR, WeaponType.BOMB)
        ),
        "us_helo_1" to UnitStats(
            "us_helo_1", "AH-64 Apache", "США", UnitType.AVIATION, UnitClass.HELICOPTER, 1,
            "helo_icon", 80, 50, 75, 75, 75,
            listOf(WeaponType.ROCKET_AIR, WeaponType.ATGM, WeaponType.MACHINE_GUN)
        )
    )

    fun getStats(unitId: String): UnitStats? {
        return statsMap[unitId]
    }

    fun getWeaponIcon(type: WeaponType): String {
        return when (type) {
            WeaponType.CANNON -> "🔫"
            WeaponType.ATGM -> "🎯"
            WeaponType.MACHINE_GUN -> "🔫"
            WeaponType.ROCKET -> "🚀"
            WeaponType.GRENADE -> "💥"
            WeaponType.RIFLE -> "🔫"
            WeaponType.SNIPER_RIFLE -> "🎯"
            WeaponType.RPG -> "💥"
            WeaponType.PISTOL -> "🔫"
            WeaponType.MISSILE -> "🚀"
            WeaponType.BOMB -> "💣"
            WeaponType.CANNON_AIR -> "🔫"
            WeaponType.ROCKET_AIR -> "🚀"
        }
    }

    fun getWeaponName(type: WeaponType): String {
        return when (type) {
            WeaponType.CANNON -> "Пушка"
            WeaponType.ATGM -> "ПТУР"
            WeaponType.MACHINE_GUN -> "Пулемет"
            WeaponType.ROCKET -> "Ракеты"
            WeaponType.GRENADE -> "Гранаты"
            WeaponType.RIFLE -> "Винтовка"
            WeaponType.SNIPER_RIFLE -> "Снайперская"
            WeaponType.RPG -> "РПГ"
            WeaponType.PISTOL -> "Пистолет"
            WeaponType.MISSILE -> "Ракеты"
            WeaponType.BOMB -> "Бомбы"
            WeaponType.CANNON_AIR -> "Пушки"
            WeaponType.ROCKET_AIR -> "НУРС"
        }
    }
}