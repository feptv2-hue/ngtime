package com.example.hhh.game.config

import android.graphics.Rect

object GameConfig {
    // Размеры экрана
    var screenWidth: Int = 0
    var screenHeight: Int = 0

    // Настройки игры
    const val TARGET_FPS = 60
    const val GAME_SPEED = 1.0f

    // Границы игрового мира
    lateinit var worldBounds: Rect
        private set

    fun initialize(width: Int, height: Int) {
        screenWidth = width
        screenHeight = height
        worldBounds = Rect(0, 0, width, height)
    }
}