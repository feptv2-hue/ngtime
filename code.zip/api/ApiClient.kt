// com/example/hhh/game/api/ApiClient.kt
package com.example.hhh.game.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface ApiService {
    // Аутентификация
    @POST("/api/auth/register")
    suspend fun register(
        @Body request: AuthRequest
    ): AuthResponse

    @POST("/api/auth/login")
    suspend fun login(
        @Body request: AuthRequest
    ): AuthResponse

    // Игрок
    @GET("/api/player/{username}")
    suspend fun getPlayerData(
        @Path("username") username: String
    ): PlayerDataResponse

    @POST("/api/player/slots")
    suspend fun saveSlots(
        @Body request: SaveSlotsRequest
    ): BaseResponse
}

// Data classes
data class AuthRequest(
    val username: String,
    val password: String
)

data class AuthResponse(
    val success: Boolean,
    val playerId: String,
    val playerName: String,
    val sessionToken: String,
    val slots: List<String?>,
    val message: String? = null,
    val error: String? = null
)

data class SaveSlotsRequest(
    val username: String,
    val slots: List<String?>
)

data class PlayerDataResponse(
    val success: Boolean,
    val playerId: String,
    val playerName: String,
    val slots: List<String?>,
    val error: String? = null
)

data class BaseResponse(
    val success: Boolean,
    val error: String? = null
)

object ApiClient {
    // 🔥 ЗАМЕНИ НА СВОЙ URL
    private const val BASE_URL = "https://war-rts-server.onrender.com/"

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
}