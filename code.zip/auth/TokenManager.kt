package com.example.hhh.game.auth

import android.content.Context
import android.content.SharedPreferences

class TokenManager(private val context: Context) {
    companion object {
        private const val PREFS_NAME = "game_prefs"
        private const val KEY_SESSION_TOKEN = "session_token"
        private const val KEY_PLAYER_ID = "player_id"
        private const val KEY_PLAYER_NAME = "player_name"
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveSession(token: String, playerId: String, playerName: String) {
        prefs.edit().apply {
            putString(KEY_SESSION_TOKEN, token)
            putString(KEY_PLAYER_ID, playerId)
            putString(KEY_PLAYER_NAME, playerName)
            apply()
        }
    }

    fun getSessionToken(): String? = prefs.getString(KEY_SESSION_TOKEN, null)
    fun getPlayerId(): String? = prefs.getString(KEY_PLAYER_ID, null)
    fun getPlayerName(): String? = prefs.getString(KEY_PLAYER_NAME, null)

    fun isLoggedIn(): Boolean = getSessionToken() != null

    fun clear() {
        prefs.edit().clear().apply()
    }
}