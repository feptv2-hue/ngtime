// com/example/hhh/game/managers/SpawnManager.kt
package com.example.hhh.game.managers

import android.content.Context
import android.graphics.Canvas
import com.example.hhh.game.config.UnitData
import com.example.hhh.game.config.UnitStatsConfig
import com.example.hhh.game.entities.UnitEntity
import com.example.hhh.game.map.MapConfig
import com.example.hhh.game.map.ZoneUtils
// com/example/hhh/game/managers/SpawnManager.kt
// В самом начале файла добавь:

import com.example.hhh.game.GameScreen
class SpawnManager(private val context: Context) {

    private val units = mutableListOf<UnitEntity>()
    private var selectedUnitData: UnitData? = null
    private var isSpawningMode = false

    var onSpawnPointSelected: ((Float, Float) -> Unit)? = null

    fun selectUnitForSpawn(unitData: UnitData) {
        selectedUnitData = unitData
        isSpawningMode = true
        println("🎯 Выбран юнит для спавна: ${unitData.name}")
    }

    fun cancelSpawning() {
        selectedUnitData = null
        isSpawningMode = false
        println("❌ Спавн отменен")
    }

    fun handleMapClick(x: Float, y: Float): Boolean {
        if (!isSpawningMode || selectedUnitData == null) return false

        val zonesAtPoint = MapConfig.getZonesAtPoint(x, y)
        val spawnZone = zonesAtPoint.find { it.type == MapConfig.ZoneType.SPAWN }

        if (spawnZone != null) {
            val unit = spawnUnit(selectedUnitData!!, x, y)
            if (unit != null) {
                units.add(unit)
                println("✅ Юнит ${unit.data.name} заспавнен в зоне ${spawnZone.name}")
                isSpawningMode = false
                selectedUnitData = null
                return true
            }
        } else {
            println("⚠️ Клик не в зоне спавна!")
        }

        return false
    }

    /**
     * Создать юнита с загрузкой текстур
     */
    private fun spawnUnit(data: UnitData, x: Float, y: Float): UnitEntity? {
        val stats = UnitStatsConfig.getStats(data.id) ?: return null

        // 🔥 ИСПРАВЛЕНО: используем startX и startY
        val unit = UnitEntity(
            data = data,
            stats = stats,
            startX = x,
            startY = y
        )

        // Загружаем текстуры из assets
        unit.loadTextures(context)

        return unit
    }

    fun getUnits(): List<UnitEntity> = units

    fun update(deltaTime: Float) {
        units.forEach { it.update(deltaTime) }
    }

    // com/example/hhh/game/managers/SpawnManager.kt
// ЗАМЕНИТЕ МЕТОД draw(canvas: Canvas) НА ЭТОТ:

    fun draw(canvas: Canvas, gameScreen: GameScreen) {
        units.forEach { it.draw(canvas, gameScreen) }
    }

    fun isSpawningMode(): Boolean = isSpawningMode

    fun getSelectedUnit(): UnitData? = selectedUnitData

    fun clearUnits() {
        units.clear()
    }
}