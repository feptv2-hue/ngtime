package com.example.hhh.game.map

class TileMap(val width: Int, val height: Int) {
    // Используем Array<Array<Tile?>> с вопросительным знаком
    val tiles: Array<Array<Tile?>> = Array(height) { arrayOfNulls<Tile>(width) }

    fun getTile(x: Int, y: Int): Tile? {
        return if (x in 0 until width && y in 0 until height) tiles[y][x] else null
    }

    fun setTile(x: Int, y: Int, tile: Tile) {
        if (x in 0 until width && y in 0 until height) {
            tiles[y][x] = tile
        }
    }
}