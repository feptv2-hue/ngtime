// com/example/hhh/game/map/MapConfig.kt
package com.example.hhh.game.map

import android.graphics.Rect

object MapConfig {
    const val TILE_SIZE = 32
    const val MAP_WIDTH = 100
    const val MAP_HEIGHT = 100
    const val CHUNK_SIZE = 8

    const val MIN_ZOOM = 0.3f
    const val MAX_ZOOM = 3.0f

    enum class TileType {
        GRASS,  // gid = 1
        SAND    // gid = 2
    }

    // ============================================
    // 🔥 НОВОЕ: СИСТЕМА ЗОН
    // ============================================

    /**
     * Зона на карте (спавн, захват, и т.д.)
     * @param id уникальный идентификатор зоны
     * @param name название зоны (для отладки)
     * @param rect прямоугольник в мировых координатах (пиксели)
     * @param type тип зоны
     */
    data class Zone(
        val id: String,
        val name: String,
        val rect: Rect,
        val type: ZoneType
    )

    enum class ZoneType {
        SPAWN,      // Зона спавна юнитов
        CAPTURE,    // Зона захвата
        RESOURCE,   // Ресурсная зона
        RESTRICTED  // Запретная зона
    }

    // Список зон на карте
    val zones: List<Zone> by lazy { generateZones() }

    private fun generateZones(): List<Zone> {
        val tileSize = TILE_SIZE
        return listOf(
            // 🔥 ЗОНА 1: Спавн в центре карты
            Zone(
                id = "spawn_center",
                name = "Центральный спавн",
                rect = Rect(
                    (MAP_WIDTH / 2 - 5) * tileSize,     // left
                    (MAP_HEIGHT / 2 - 5) * tileSize,    // top
                    (MAP_WIDTH / 2 + 5) * tileSize,     // right
                    (MAP_HEIGHT / 2 + 5) * tileSize     // bottom
                ),
                type = ZoneType.SPAWN
            ),

            // 🔥 ЗОНА 2: Дополнительный спавн слева
            Zone(
                id = "spawn_left",
                name = "Левый спавн",
                rect = Rect(
                    5 * tileSize,
                    45 * tileSize,
                    15 * tileSize,
                    55 * tileSize
                ),
                type = ZoneType.SPAWN
            ),

            // 🔥 ЗОНА 3: Дополнительный спавн справа
            Zone(
                id = "spawn_right",
                name = "Правый спавн",
                rect = Rect(
                    85 * tileSize,
                    45 * tileSize,
                    95 * tileSize,
                    55 * tileSize
                ),
                type = ZoneType.SPAWN
            ),

            // 🔥 ЗОНА 4: Зона захвата (пример)
            Zone(
                id = "capture_point_1",
                name = "Точка захвата A",
                rect = Rect(
                    40 * tileSize,
                    40 * tileSize,
                    60 * tileSize,
                    60 * tileSize
                ),
                type = ZoneType.CAPTURE
            )
        )
    }

    /**
     * Получить все зоны определенного типа
     */
    fun getZonesByType(type: ZoneType): List<Zone> {
        return zones.filter { it.type == type }
    }

    /**
     * Получить зону по ID
     */
    fun getZoneById(id: String): Zone? {
        return zones.find { it.id == id }
    }

    /**
     * Проверить, находится ли точка в любой зоне
     */
    fun isPointInAnyZone(x: Float, y: Float): Boolean {
        return zones.any { it.rect.contains(x.toInt(), y.toInt()) }
    }

    /**
     * Получить все зоны, содержащие точку
     */
    fun getZonesAtPoint(x: Float, y: Float): List<Zone> {
        return zones.filter { it.rect.contains(x.toInt(), y.toInt()) }
    }
}