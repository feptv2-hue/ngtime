package com.example.hhh.game.map

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Bitmap.Config

class TileAtlas(private val context: Context) {
    private val tileCache = mutableMapOf<Int, Bitmap>()
    private val tileSize = MapConfig.TILE_SIZE

    init {
        loadAllTiles()
    }

    private fun loadAllTiles() {
        // Загрузка травы (gid = 1)
        val grassResId = context.resources.getIdentifier(
            "tile_grass",
            "drawable",
            context.packageName
        )
        tileCache[1] = if (grassResId != 0) {
            loadTile(grassResId)
        } else {
            createFallbackTile(Color.parseColor("#4CAF50"))
        }

        // Загрузка песка (gid = 2)
        val sandResId = context.resources.getIdentifier(
            "tile_sand",
            "drawable",
            context.packageName
        )
        tileCache[2] = if (sandResId != 0) {
            loadTile(sandResId)
        } else {
            createFallbackTile(Color.parseColor("#F5E6CA"))
        }
    }

    private fun loadTile(resourceId: Int): Bitmap {
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Config.ARGB_8888
            inScaled = false
        }
        val bmp = BitmapFactory.decodeResource(context.resources, resourceId, options)
        try { bmp.setDensity(0) } catch (_: Throwable) {}
        return bmp
    }

    private fun createFallbackTile(color: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(tileSize, tileSize, Config.ARGB_8888)
        try { bitmap.setDensity(0) } catch (_: Throwable) {}
        val canvas = Canvas(bitmap)
        canvas.drawColor(color)
        return bitmap
    }

    fun getTile(gid: Int): Bitmap {
        return tileCache[gid] ?: tileCache[1] ?: throw IllegalStateException("Tile not found")
    }

    fun release() {
        tileCache.values.forEach { it.recycle() }
        tileCache.clear()
    }
}