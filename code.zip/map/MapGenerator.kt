// com/example/hhh/game/map/MapGenerator.kt
package com.example.hhh.game.map

import android.graphics.Rect

object MapGenerator {
    fun generateTestMap(width: Int, height: Int): TileMap {
        val map = TileMap(width, height)

        for (y in 0 until height) {
            for (x in 0 until width) {
                val type = when {
                    // Песок - полоса в центре карты
                    x in 40..60 && y in 40..60 -> MapConfig.TileType.SAND
                    // Трава - всё остальное
                    else -> MapConfig.TileType.GRASS
                }
                val gid = when (type) {
                    MapConfig.TileType.GRASS -> 1
                    MapConfig.TileType.SAND -> 2
                }
                map.tiles[y]?.set(x, Tile(type, gid))
            }
        }

        return map
    }

    // 🔥 НОВОЕ: Получить зоны для карты (можно использовать для отладки)
    fun getMapZones(): List<MapConfig.Zone> {
        return MapConfig.zones
    }
}