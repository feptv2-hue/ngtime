package com.example.hhh.game.map

data class Tile(
    val type: MapConfig.TileType,
    val gid: Int  // ID в текстуре-атласе
)