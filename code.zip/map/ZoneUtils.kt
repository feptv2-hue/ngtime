// com/example/hhh/game/map/ZoneUtils.kt
package com.example.hhh.game.map

import android.graphics.Rect
import kotlin.math.sqrt

object ZoneUtils {

    /**
     * Проверить, пересекаются ли две зоны
     */
    fun zonesIntersect(zone1: MapConfig.Zone, zone2: MapConfig.Zone): Boolean {
        return Rect.intersects(zone1.rect, zone2.rect)
    }

    /**
     * Получить центр зоны
     */
    fun getZoneCenter(zone: MapConfig.Zone): Pair<Float, Float> {
        return Pair(
            zone.rect.centerX().toFloat(),
            zone.rect.centerY().toFloat()
        )
    }

    /**
     * Проверить, находится ли юнит в зоне
     */
    fun isUnitInZone(unitX: Float, unitY: Float, zone: MapConfig.Zone): Boolean {
        return zone.rect.contains(unitX.toInt(), unitY.toInt())
    }

    /**
     * Получить случайную точку внутри зоны
     */
    fun getRandomPointInZone(zone: MapConfig.Zone): Pair<Float, Float> {
        val x = zone.rect.left + Math.random() * zone.rect.width()
        val y = zone.rect.top + Math.random() * zone.rect.height()
        return Pair(x.toFloat(), y.toFloat())
    }

    /**
     * Получить все зоны спавна
     */
    fun getSpawnZones(): List<MapConfig.Zone> {
        return MapConfig.getZonesByType(MapConfig.ZoneType.SPAWN)
    }

    /**
     * Получить первую зону спавна (для спавна игрока)
     */
    fun getDefaultSpawnZone(): MapConfig.Zone? {
        return getSpawnZones().firstOrNull()
    }

    /**
     * Получить позицию для спавна юнита в зоне
     */
    fun getSpawnPosition(zone: MapConfig.Zone, margin: Int = 20): Pair<Float, Float> {
        val centerX = zone.rect.centerX().toFloat()
        val centerY = zone.rect.centerY().toFloat()
        // Можно добавить небольшое случайное смещение
        val offsetX = (Math.random() * margin * 2 - margin).toFloat()
        val offsetY = (Math.random() * margin * 2 - margin).toFloat()
        return Pair(centerX + offsetX, centerY + offsetY)
    }

    /**
     * Найти ближайшую зону к точке
     */
    fun findNearestZone(x: Float, y: Float, type: MapConfig.ZoneType? = null): MapConfig.Zone? {
        val zones = if (type != null) {
            MapConfig.getZonesByType(type)
        } else {
            MapConfig.zones
        }

        if (zones.isEmpty()) return null

        return zones.minByOrNull { zone ->
            val centerX = zone.rect.centerX().toFloat()
            val centerY = zone.rect.centerY().toFloat()
            val dx = x - centerX
            val dy = y - centerY
            sqrt(dx * dx + dy * dy)
        }
    }
}