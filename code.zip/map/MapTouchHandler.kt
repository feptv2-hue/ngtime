package com.example.hhh.game.map

import android.view.MotionEvent
import kotlin.math.sqrt

class MapTouchHandler(
    private val onPan: (Float, Float) -> Unit,
    private val onZoom: (Float, Float, Float) -> Unit  // scale, pivotX, pivotY
) {
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var initialDistance = 0f
    private var isZooming = false
    private var zoomPivotX = 0f
    private var zoomPivotY = 0f

    fun handleTouch(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                isZooming = false
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount == 2) {
                    initialDistance = getDistance(event)
                    zoomPivotX = (event.getX(0) + event.getX(1)) / 2f
                    zoomPivotY = (event.getY(0) + event.getY(1)) / 2f
                    isZooming = true
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !isZooming) {
                    val dx = lastTouchX - event.x
                    val dy = lastTouchY - event.y
                    onPan(dx, dy)
                    lastTouchX = event.x
                    lastTouchY = event.y
                    return true
                }

                if (event.pointerCount >= 2 && isZooming) {
                    val currentDistance = getDistance(event)
                    if (initialDistance > 10f) {
                        val scale = currentDistance / initialDistance
                        onZoom(scale, zoomPivotX, zoomPivotY)
                        initialDistance = currentDistance
                    }
                    return true
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                isZooming = false
                return true
            }
        }
        return false
    }

    private fun getDistance(event: MotionEvent): Float {
        if (event.pointerCount < 2) return 0f
        val x1 = event.getX(0)
        val y1 = event.getY(0)
        val x2 = event.getX(1)
        val y2 = event.getY(1)
        return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1))
    }
}