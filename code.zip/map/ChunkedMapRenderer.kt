package com.example.hhh.game.map

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Bitmap.Config
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min
import kotlin.math.floor
import kotlin.math.ceil
import java.util.LinkedHashMap
import java.util.ArrayDeque

/**
 * ChunkedMapRenderer с приоритетной асинхронной генерацией чанков и fallback'ом на соседний чанк.
 *
 * Исправления в этой версии:
 *  - adjustCacheLimitByViewport() больше не обрезает кэш синхронно и агрессивно на КАЖДЫЙ
 *    вызов setViewport(). Раньше во время zoom-жеста (когда мировой viewport меняется на
 *    каждый кадр) лимит кэша пересчитывался и уменьшался мгновенно, из-за чего чанки,
 *    которые прямо сейчас видны на экране, могли быть выброшены/recycled ДО того как
 *    render() успевал обновить их LRU-порядок на этот кадр — отсюда "поломки"/мигание
 *    именно при зуме (при панорамировании zoom не менялся, лимит кэша не пересчитывался,
 *    поэтому всё было гладко).
 *    Теперь лимит растёт сразу (это безопасно), а уменьшается не чаще раза в
 *    CACHE_ADJUST_MIN_INTERVAL_MS и не более чем на CACHE_SHRINK_FACTOR за шаг.
 *  - setViewport() больше не чистит pendingDeque целиком на каждый вызов. Вместо этого
 *    воркер сам проверяет актуальность чанка (isChunkStillNeeded) перед тем как его
 *    рендерить, и просто пропускает устаревшие запросы. Это убирает гонку
 *    "запрос → сброс очереди → повторный запрос", которая при быстрых zoom-жестах
 *    (много touch-move событий в секунду) не давала воркеру угнаться за кадрами.
 *  - Устранена инверсия порядка блокировок: раньше drawChunkAtScreen мог взять cacheLock
 *    и внутри него — pendingDeque, а workerLoop брал pendingDeque и внутри — cacheLock.
 *    Это потенциальный deadlock при высокой частоте новых запросов (как раз во время
 *    активного зума). Теперь порядок везде единый: pendingDeque никогда не берётся
 *    изнутри cacheLock.
 */
class ChunkedMapRenderer(
    private val tileMap: TileMap,
    private val tileAtlas: TileAtlas
) {
    private val USE_ARGB_8888 = true

    // world viewport в мировых пикселях (устанавливает GameScreen)
    @Volatile
    private var viewport = Rect()
    @Volatile
    private var zoom = 1.0f
    @Volatile
    private var offsetX = 0f
    @Volatile
    private var offsetY = 0f

    // paint без фильтра для чётких пикселей
    private val bitmapPaint = Paint().apply {
        isFilterBitmap = false
        isAntiAlias = false
        isDither = false
    }

    // LRU-кэш (accessOrder = true)
    private val cacheLock = Any()
    private val chunkCache = LinkedHashMap<Pair<Int, Int>, Bitmap>(16, 0.75f, true)
    private var currentCacheBytes: Long = 0L
    private var chunksCached = 0

    // Генерируемые ключи
    private val generating = mutableSetOf<Pair<Int, Int>>()

    // Pending deque для приоритетной генерации (addFirst = высокий приоритет)
    private val pendingDeque = ArrayDeque<Pair<Int, Int>>()

    // Worker thread
    @Volatile
    private var workerRunning = true
    private val workerThread: Thread

    private val chunkSize = MapConfig.CHUNK_SIZE
    private val tileSize = MapConfig.TILE_SIZE

    // Memory limit (bytes)
    private var maxCacheBytes: Long = calcDefaultMaxCacheBytes()

    // --- Троттлинг пересчёта лимита кэша (см. пояснение в шапке класса) ---
    private var lastCacheShrinkTime = 0L
    private val CACHE_ADJUST_MIN_INTERVAL_MS = 150L
    private val CACHE_SHRINK_FACTOR = 0.7f // за один шаг лимит не может упасть более чем на 30%

    // Запас (в чанках) вокруг viewport, в пределах которого запрос на генерацию чанка
    // всё ещё считается актуальным. Нужен, чтобы во время быстрого зума/пана воркер не
    // тратил время на чанки, которые уже вышли далеко за пределы экрана.
    private val STALE_CHUNK_MARGIN_IN_CHUNKS = 2

    var chunksRendered = 0
    var renderTime = 0L

    init {
        workerThread = Thread(Runnable { workerLoop() }, "ChunkRendererWorker")
        workerThread.isDaemon = true
        workerThread.start()
    }

    private fun calcDefaultMaxCacheBytes(): Long {
        return try {
            val rt = Runtime.getRuntime()
            max(16L * 1024 * 1024, rt.maxMemory() / 8)
        } catch (t: Throwable) {
            16L * 1024 * 1024
        }
    }

    fun setViewport(viewport: Rect) {
        // viewport в мировых пикселях
        this.viewport = Rect(viewport)
        adjustCacheLimitByViewport()
        // Раньше здесь была полная очистка pendingDeque на каждый вызов — это и было
        // источником "поломок" при зуме. Очередь больше не чистится: устаревшие запросы
        // отсеиваются воркером через isChunkStillNeeded() перед рендером конкретного чанка.
    }

    private fun adjustCacheLimitByViewport() {
        val chunkPixel = chunkSize * tileSize
        val visibleX = max(1, ceil(viewport.width().toFloat() / chunkPixel).toInt())
        val visibleY = max(1, ceil(viewport.height().toFloat() / chunkPixel).toInt())
        val preload = 4
        val targetChunks = (visibleX + preload) * (visibleY + preload)
        val bytesPerPixel = if (USE_ARGB_8888) 4 else 2
        val chunkByteEst = (chunkSize.toLong() * tileSize.toLong() * chunkSize.toLong() * tileSize.toLong() * bytesPerPixel)
        val targetBytes = chunkByteEst * targetChunks
        val rt = Runtime.getRuntime()
        val safeMax = max(16L * 1024 * 1024, rt.maxMemory() / 4)
        val computed = min(safeMax, max(16L * 1024 * 1024, targetBytes))

        synchronized(cacheLock) {
            if (computed >= maxCacheBytes) {
                // Расти можно сразу — это ничего не ломает, просто разрешаем кэшу быть больше.
                maxCacheBytes = computed
            } else {
                // Уменьшаем лимит плавно и не чаще раза в CACHE_ADJUST_MIN_INTERVAL_MS,
                // чтобы во время активного зума не срезать синхронно чанки,
                // которые прямо сейчас видны на экране.
                val now = System.currentTimeMillis()
                if (now - lastCacheShrinkTime >= CACHE_ADJUST_MIN_INTERVAL_MS) {
                    val minAllowed = (maxCacheBytes * CACHE_SHRINK_FACTOR).toLong()
                    maxCacheBytes = max(computed, minAllowed)
                    lastCacheShrinkTime = now
                }
            }
            pruneCache()
        }
    }

    fun setZoom(zoom: Float) {
        this.zoom = zoom.coerceIn(MapConfig.MIN_ZOOM, MapConfig.MAX_ZOOM)
    }

    fun setOffset(offsetX: Float, offsetY: Float) {
        this.offsetX = offsetX
        this.offsetY = offsetY
    }

    // Запас в чанках вокруг видимой области. Чанки в этой зоне запрашиваются на генерацию
    // ЗАРАНЕЕ, до того как реально попадут в кадр. Без этого запаса чанк начинал
    // генерироваться только в момент появления на экране, и пока воркер его не успевал
    // отрисовать — было видно "пустое место"/заглушку вместо стыковки с соседним чанком.
    // Именно поэтому проблема проявлялась только при движении камеры: в статике всё
    // успевало прогрузиться и закешироваться.
    private val RENDER_PRELOAD_MARGIN_CHUNKS = 1

    fun render(canvas: Canvas) {
        val start = System.currentTimeMillis()

        // Не используем canvas.scale/translate — вычисляем экранные позиции
        val worldLeft = viewport.left.toFloat()
        val worldTop = viewport.top.toFloat()
        val worldRight = viewport.right.toFloat()
        val worldBottom = viewport.bottom.toFloat()

        val startTileX = max(0, floor(worldLeft / tileSize).toInt())
        val endTileX = min(tileMap.width, ceil(worldRight / tileSize).toInt())
        val startTileY = max(0, floor(worldTop / tileSize).toInt())
        val endTileY = min(tileMap.height, ceil(worldBottom / tileSize).toInt())

        val totalChunksX = (tileMap.width + chunkSize - 1) / chunkSize
        val totalChunksY = (tileMap.height + chunkSize - 1) / chunkSize

        val startChunkX = max(0, startTileX / chunkSize - RENDER_PRELOAD_MARGIN_CHUNKS)
        val endChunkX = min(totalChunksX, (endTileX + chunkSize - 1) / chunkSize + RENDER_PRELOAD_MARGIN_CHUNKS)
        val startChunkY = max(0, startTileY / chunkSize - RENDER_PRELOAD_MARGIN_CHUNKS)
        val endChunkY = min(totalChunksY, (endTileY + chunkSize - 1) / chunkSize + RENDER_PRELOAD_MARGIN_CHUNKS)

        chunksRendered = 0

        // КЛЮЧЕВОЙ ФИКС "расползающихся стыков" при движении камеры: offsetX/offsetY/zoom
        // читаются здесь ОДИН РАЗ на весь кадр и передаются одним и тем же значением во все
        // вызовы drawChunkAtScreen(). Раньше каждый чанк сам читал instance-поля
        // this.offsetX/this.offsetY/this.zoom внутри drawChunkAtScreen(). Эти поля меняются
        // с потока ввода (onPan/onZoom в GameScreen) АСИНХРОННО, параллельно с тем, как
        // render() идёт по циклу и рисует чанки один за другим. Если offset менялся между
        // отрисовкой чанка A и соседнего чанка B В ПРЕДЕЛАХ ОДНОГО КАДРА, они считали свои
        // экранные координаты по разным offset — отсюда щель между двумя чанками именно во
        // время движения камеры, которая сама пропадала, как только offset переставал
        // меняться (камера останавливалась). Снимок ниже гарантирует, что все чанки одного
        // кадра всегда используют идентичные offset/zoom.
        val renderOffsetX = offsetX
        val renderOffsetY = offsetY
        val renderZoom = zoom

        for (cy in startChunkY until endChunkY) {
            for (cx in startChunkX until endChunkX) {
                if (cx >= 0 && cy >= 0 &&
                    cx * chunkSize < tileMap.width &&
                    cy * chunkSize < tileMap.height
                ) {
                    drawChunkAtScreen(canvas, cx, cy, renderOffsetX, renderOffsetY, renderZoom)
                    chunksRendered++
                }
            }
        }

        renderTime = System.currentTimeMillis() - start
    }

    private fun drawChunkAtScreen(
        canvas: Canvas,
        chunkX: Int,
        chunkY: Int,
        offsetX: Float,
        offsetY: Float,
        zoom: Float
    ) {
        val key = Pair(chunkX, chunkY)

        // Геометрия чанка в мировых и экранных координатах — блокировки не требует.
        val chunkTileCountX = min(chunkSize, tileMap.width - chunkX * chunkSize)
        val chunkTileCountY = min(chunkSize, tileMap.height - chunkY * chunkSize)
        val chunkPixelW = chunkTileCountX * tileSize
        val chunkPixelH = chunkTileCountY * tileSize

        val worldX = (chunkX * chunkSize * tileSize).toFloat()
        val worldY = (chunkY * chunkSize * tileSize).toFloat()

        // offsetX/offsetY/zoom здесь — это параметры (снимок кадра из render()), а НЕ
        // instance-поля класса. Так все чанки одного render()-прохода гарантированно
        // считают координаты по одинаковым значениям.
        val EPS = 1e-4f
        val sLeft = floor(((worldX - offsetX) * zoom) + EPS).toInt()
        val sTop = floor(((worldY - offsetY) * zoom) + EPS).toInt()
        val sRight = ceil((((worldX + chunkPixelW) - offsetX) * zoom) - EPS).toInt()
        val sBottom = ceil((((worldY + chunkPixelH) - offsetY) * zoom) - EPS).toInt()

        if (sRight <= sLeft || sBottom <= sTop) return

        var needsRequest = false
        var drawn = false

        // КРИТИЧЕСКИ ВАЖНО: поиск bitmap'а в кэше И сам canvas.drawBitmap() должны быть
        // ВНУТРИ одного и того же synchronized(cacheLock) блока. Раньше bitmap читался из
        // кэша под локом, а рисовался уже ПОСЛЕ его освобождения — в этом окне воркер
        // (pruneCache/clearCache) мог recycle() этот же bitmap на другом потоке, и
        // canvas.drawBitmap() падал с "Canvas: trying to use a recycled bitmap".
        // Именно зум чаще всего триггерит пересчёт лимита кэша и эвикцию чанков, поэтому
        // краш проявлялся преимущественно во время zoom-жестов. Держа обе операции под
        // одним локом, recycle() физически не может произойти между поиском и отрисовкой.
        synchronized(cacheLock) {
            val bmp = chunkCache[key]
            if (bmp != null && !bmp.isRecycled) {
                val dst = Rect(sLeft, sTop, sRight, sBottom)
                canvas.drawBitmap(bmp, null, dst, bitmapPaint)
                drawn = true
            } else {
                if (!generating.contains(key)) needsRequest = true

                val neighbor = findNearestCachedNeighborLocked(chunkX, chunkY)
                if (neighbor != null) {
                    val dst = Rect(sLeft, sTop, sRight, sBottom)
                    canvas.drawBitmap(neighbor, null, dst, bitmapPaint)
                    drawn = true
                }
            }
        }

        // Запрос на генерацию делаем ПОСЛЕ выхода из cacheLock, чтобы не держать
        // одновременно cacheLock и pendingDeque (единый порядок блокировок — см. шапку класса).
        if (needsRequest) {
            requestChunkInternal(key, highPriority = true)
        }

        if (!drawn) {
            val p = Paint().apply {
                color = Color.parseColor("#4CAF50")
                style = Paint.Style.FILL
            }
            canvas.drawRect(sLeft.toFloat(), sTop.toFloat(), sRight.toFloat(), sBottom.toFloat(), p)
        }
    }

    /** Вызывать только изнутри synchronized(cacheLock) — иначе найденный bitmap не защищён от recycle(). */
    private fun findNearestCachedNeighborLocked(cx: Int, cy: Int): Bitmap? {
        val maxR = 2
        for (r in 1..maxR) {
            for (dy in -r..r) {
                for (dx in -r..r) {
                    if (kotlin.math.abs(dx) != r && kotlin.math.abs(dy) != r) continue
                    val k = Pair(cx + dx, cy + dy)
                    val bmp = chunkCache[k]
                    if (bmp != null && !bmp.isRecycled) {
                        return bmp
                    }
                }
            }
        }
        return null
    }

    private fun requestChunkInternal(key: Pair<Int, Int>, highPriority: Boolean) {
        synchronized(pendingDeque) {
            if (pendingDeque.contains(key)) {
                if (highPriority) {
                    pendingDeque.remove(key)
                    pendingDeque.addFirst(key)
                }
            } else {
                if (highPriority) pendingDeque.addFirst(key) else pendingDeque.addLast(key)
            }
            try {
                (pendingDeque as java.lang.Object).notifyAll()
            } catch (_: Throwable) {}
        }
    }

    /**
     * Проверяет, всё ещё ли актуален чанк относительно текущего viewport (с запасом).
     * Используется воркером, чтобы отбрасывать устаревшие запросы, накопившиеся в очереди
     * во время быстрого зума/пана, вместо того чтобы чистить всю очередь при каждом кадре.
     */
    private fun isChunkStillNeeded(chunkX: Int, chunkY: Int): Boolean {
        val vp = viewport
        if (vp.width() <= 0 || vp.height() <= 0) return true // ещё не инициализирован — не рискуем

        val chunkPixelSize = chunkSize * tileSize
        val marginPx = STALE_CHUNK_MARGIN_IN_CHUNKS * chunkPixelSize

        val chunkLeft = chunkX * chunkPixelSize
        val chunkTop = chunkY * chunkPixelSize
        val chunkRight = chunkLeft + chunkPixelSize
        val chunkBottom = chunkTop + chunkPixelSize

        return chunkRight >= vp.left - marginPx &&
                chunkLeft <= vp.right + marginPx &&
                chunkBottom >= vp.top - marginPx &&
                chunkTop <= vp.bottom + marginPx
    }

    // Worker loop: берёт ключи из pendingDeque и рендерит чанки
    private fun workerLoop() {
        while (workerRunning) {
            val key: Pair<Int, Int>?

            synchronized(pendingDeque) {
                while (pendingDeque.isEmpty() && workerRunning) {
                    try {
                        (pendingDeque as java.lang.Object).wait()
                    } catch (_: InterruptedException) {
                        // ignore
                    }
                }
                if (!workerRunning) break
                key = pendingDeque.pollFirst()
            }

            if (key == null) continue

            // Отбрасываем устаревшие запросы (актуально при быстром зуме/пане) вместо
            // траты времени воркера и памяти на чанк, который уже не виден.
            if (!isChunkStillNeeded(key.first, key.second)) {
                continue
            }

            synchronized(cacheLock) {
                if (chunkCache.containsKey(key) || generating.contains(key)) continue
                generating.add(key)
            }

            try {
                val (cx, cy) = key
                val bmp = renderChunk(cx, cy)
                synchronized(cacheLock) {
                    if (!workerRunning) {
                        try { bmp.recycle() } catch (_: Throwable) {}
                    } else {
                        chunkCache[key] = bmp
                        currentCacheBytes += safeByteCount(bmp)
                        chunksCached = chunkCache.size
                        pruneCache()
                    }
                    generating.remove(key)
                }
            } catch (t: Throwable) {
                synchronized(cacheLock) { generating.remove(key) }
                t.printStackTrace()
            }
        }
    }

    private fun renderChunk(chunkX: Int, chunkY: Int): Bitmap {
        val startX = chunkX * chunkSize
        val startY = chunkY * chunkSize
        val endX = min(startX + chunkSize, tileMap.width)
        val endY = min(startY + chunkSize, tileMap.height)

        val bmpWidth = (endX - startX) * tileSize
        val bmpHeight = (endY - startY) * tileSize
        val config = if (USE_ARGB_8888) Config.ARGB_8888 else Config.RGB_565
        val bitmap = Bitmap.createBitmap(bmpWidth, bmpHeight, config)
        try { bitmap.setDensity(0) } catch (_: Throwable) {}
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.parseColor("#4CAF50"))

        for (ty in startY until endY) {
            for (tx in startX until endX) {
                val tile = tileMap.getTile(tx, ty)
                tile?.let {
                    val tileBitmap = tileAtlas.getTile(it.gid)
                    try { tileBitmap.setDensity(0) } catch (_: Throwable) {}

                    val dstLeft = (tx - startX) * tileSize
                    val dstTop = (ty - startY) * tileSize
                    // ВАЖНО: всегда рисуем тайл в явный dst Rect размером tileSize x tileSize,
                    // а не просто по координатам x,y. TileAtlas больше не подгоняет исходное
                    // изображение под tileSize при загрузке (это и давало размытие через
                    // createScaledBitmap с билинейной фильтрацией) — теперь картинка может
                    // быть любого нативного разрешения. Без dst Rect drawBitmap(bmp, x, y, ..)
                    // рисует её в РОДНОМ размере, а не в размере клетки сетки — из-за этого
                    // тайлы перекрывали/не докрывали соседние клетки и чанк выглядел криво.
                    // Масштабирование через dst Rect + bitmapPaint(isFilterBitmap=false) —
                    // жёсткое (nearest-neighbor), без размытия, и гарантированно укладывает
                    // тайл ровно в его клетку независимо от исходного разрешения картинки.
                    canvas.drawBitmap(
                        tileBitmap,
                        null,
                        Rect(dstLeft, dstTop, dstLeft + tileSize, dstTop + tileSize),
                        bitmapPaint
                    )
                }
            }
        }
        return bitmap
    }

    private fun safeByteCount(bmp: Bitmap?): Long {
        return try {
            bmp?.byteCount?.toLong() ?: 0L
        } catch (t: Throwable) {
            val w = bmp?.width ?: 0
            val h = bmp?.height ?: 0
            val bytesPerPixel = if (USE_ARGB_8888) 4 else 2
            w.toLong() * h.toLong() * bytesPerPixel
        }
    }

    private fun pruneCache() {
        synchronized(cacheLock) {
            if (currentCacheBytes <= maxCacheBytes) return
            val it = chunkCache.entries.iterator()
            while (it.hasNext() && currentCacheBytes > maxCacheBytes) {
                val e = it.next()
                try {
                    val b = e.value
                    val bc = safeByteCount(b)
                    try { b.recycle() } catch (_: Throwable) {}
                    currentCacheBytes -= bc
                } catch (_: Throwable) {}
                it.remove()
            }
            if (currentCacheBytes < 0) currentCacheBytes = 0
            chunksCached = chunkCache.size
        }
    }

    fun clearCache() {
        synchronized(cacheLock) {
            chunkCache.forEach { try { it.value.recycle() } catch (_: Throwable) {} }
            chunkCache.clear()
            generating.clear()
            currentCacheBytes = 0
            chunksCached = 0
        }
        synchronized(pendingDeque) {
            pendingDeque.clear()
            try {
                (pendingDeque as java.lang.Object).notifyAll()
            } catch (_: Throwable) {}
        }
    }

    fun getMapWidth(): Int = tileMap.width * tileSize
    fun getMapHeight(): Int = tileMap.height * tileSize

    fun release() {
        // Stop worker
        workerRunning = false
        synchronized(pendingDeque) {
            try {
                (pendingDeque as java.lang.Object).notifyAll()
            } catch (_: Throwable) {}
        }
        try { workerThread.join(200) } catch (_: Throwable) {}

        synchronized(cacheLock) { clearCache() }
    }
    // Публичный геттер для количества закешированных чанков (потокобезопасно)
    fun getChunksCached(): Int {
        synchronized(cacheLock) {
            return chunkCache.size
        }
    }
}