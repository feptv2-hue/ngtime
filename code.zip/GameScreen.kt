// com/example/hhh/game/GameScreen.kt
package com.example.hhh.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import com.example.hhh.game.map.ChunkedMapRenderer
import com.example.hhh.game.map.MapTouchHandler
import com.example.hhh.game.map.TileAtlas
import com.example.hhh.game.map.TileMap
import com.example.hhh.game.map.MapGenerator
import com.example.hhh.game.map.MapConfig

class GameScreen(
    private val context: Context
) {
    private var viewport = Rect(0, 0, 800, 600)
    private var zoom = 1.0f
    private var offsetX = 0f
    private var offsetY = 0f

    private var tileMap: TileMap = MapGenerator.generateTestMap(MapConfig.MAP_WIDTH, MapConfig.MAP_HEIGHT)
    private lateinit var tileAtlas: TileAtlas
    private lateinit var mapRenderer: ChunkedMapRenderer

    private var isInitialized = false
    private var isLoading = true

    private var initTime = 0L
    private var mapSizeKB = 0

    private var loadingProgress = 0f
    private var loadingText = "ПОДГОТОВКА КАРТЫ..."
    private var dotCount = 1
    private var lastUpdateTime = 0L

    init {
        startLoading()
    }

    private fun startLoading() {
        isLoading = true
        loadingProgress = 0f
        loadingText = "ЗАГРУЗКА ТЕКСТУР..."

        Thread {
            try {
                loadingProgress = 0.1f
                Thread.sleep(30)

                tileAtlas = TileAtlas(context)
                loadingProgress = 0.3f
                loadingText = "СОЗДАНИЕ КАРТЫ..."
                Thread.sleep(30)

                tileMap = MapGenerator.generateTestMap(MapConfig.MAP_WIDTH, MapConfig.MAP_HEIGHT)
                loadingProgress = 0.5f
                loadingText = "ПОДГОТОВКА РЕНДЕРА..."
                Thread.sleep(30)

                val startInit = System.currentTimeMillis()
                mapRenderer = ChunkedMapRenderer(tileMap, tileAtlas)
                initTime = System.currentTimeMillis() - startInit

                loadingProgress = 0.9f
                loadingText = "ФИНАЛИЗАЦИЯ..."

                val mapWidth = tileMap.width * MapConfig.TILE_SIZE
                val mapHeight = tileMap.height * MapConfig.TILE_SIZE
                mapSizeKB = (mapWidth * mapHeight * 2) / 1024

                loadingProgress = 1.0f
                loadingText = "ГОТОВО!"
                Thread.sleep(100)

                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isLoading = false
                    isInitialized = true
                    centerMap()
                    updateViewport()

                    println("=========================================")
                    println("✅ КАРТА ГОТОВА!")
                    println("   Размер: ${tileMap.width}x${tileMap.height} тайлов")
                    println("   Текстура: ${mapWidth}x${mapHeight} пикселей")
                    println("   Память: ~${mapSizeKB} KB")
                    println("   Инициализация: ${initTime}ms")
                    println("=========================================")
                }

            } catch (e: Exception) {
                e.printStackTrace()
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    loadingText = "ОШИБКА ЗАГРУЗКИ!"
                    isLoading = false
                }
            }
        }.start()
    }

    fun resetMap() {
        if (isLoading) return
        isLoading = true
        loadingProgress = 0f
        loadingText = "ПЕРЕЗАГРУЗКА..."

        Thread {
            try {
                tileMap = MapGenerator.generateTestMap(MapConfig.MAP_WIDTH, MapConfig.MAP_HEIGHT)
                mapRenderer.release()
                mapRenderer = ChunkedMapRenderer(tileMap, tileAtlas)

                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isLoading = false
                    centerMap()
                    updateViewport()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun centerMap() {
        val mapW = tileMap.width * MapConfig.TILE_SIZE.toFloat()
        val mapH = tileMap.height * MapConfig.TILE_SIZE.toFloat()
        val viewW = viewport.width() / zoom
        val viewH = viewport.height() / zoom

        offsetX = if (mapW > viewW) 0f else -(viewW - mapW) / 2f
        offsetY = if (mapH > viewH) 0f else -(viewH - mapH) / 2f
    }

    private val touchHandler = MapTouchHandler(
        onPan = { dx, dy ->
            if (!isLoading) {
                offsetX += dx / zoom
                offsetY += dy / zoom
                clampOffset()
                updateViewport()
            }
        },
        onZoom = { scale, pivotX, pivotY ->
            if (!isLoading) {
                val oldZoom = zoom
                val newZoom = (zoom * scale).coerceIn(MapConfig.MIN_ZOOM, MapConfig.MAX_ZOOM)

                val worldPivotX = offsetX + pivotX / oldZoom
                val worldPivotY = offsetY + pivotY / oldZoom

                zoom = newZoom
                offsetX = worldPivotX - pivotX / zoom
                offsetY = worldPivotY - pivotY / zoom

                clampOffset()
                updateViewport()
            }
        }
    )

    // 🔥 ИСПРАВЛЕННЫЙ clampOffset() — убрал overscroll
    private fun clampOffset() {
        val mapW = tileMap.width * MapConfig.TILE_SIZE.toFloat()
        val mapH = tileMap.height * MapConfig.TILE_SIZE.toFloat()

        val viewW = viewport.width() / zoom
        val viewH = viewport.height() / zoom

        // Минимальные и максимальные значения offset
        val minOffsetX = if (mapW <= viewW) -(viewW - mapW) / 2f else 0f
        val maxOffsetX = if (mapW <= viewW) -(viewW - mapW) / 2f else mapW - viewW

        val minOffsetY = if (mapH <= viewH) -(viewH - mapH) / 2f else 0f
        val maxOffsetY = if (mapH <= viewH) -(viewH - mapH) / 2f else mapH - viewH

        offsetX = offsetX.coerceIn(minOffsetX, maxOffsetX)
        offsetY = offsetY.coerceIn(minOffsetY, maxOffsetY)
    }

    fun draw(canvas: Canvas) {
        if (isLoading || !isInitialized) {
            drawLoadingScreen(canvas)
            return
        }

        canvas.drawColor(Color.parseColor("#1a2233"))
        mapRenderer.render(canvas)
        drawZones(canvas)
        drawDebugInfo(canvas)
    }

    private fun drawZones(canvas: Canvas) {
        val zonePaint = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = false
        }

        val labelPaint = Paint().apply {
            color = Color.WHITE
            textSize = 20f
            isAntiAlias = false
            typeface = Typeface.create("monospace", Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val zones = MapConfig.zones
        val viewW = viewport.width() / zoom
        val viewH = viewport.height() / zoom
        val left = offsetX
        val top = offsetY

        zones.forEach { zone ->
            val rect = zone.rect

            if (rect.right < left || rect.left > left + viewW ||
                rect.bottom < top || rect.top > top + viewH) {
                return@forEach
            }

            val fillPaint = Paint().apply {
                color = when (zone.type) {
                    MapConfig.ZoneType.SPAWN -> Color.parseColor("#44FFAA00")
                    MapConfig.ZoneType.CAPTURE -> Color.parseColor("#44FF4444")
                    MapConfig.ZoneType.RESOURCE -> Color.parseColor("#4444FF44")
                    MapConfig.ZoneType.RESTRICTED -> Color.parseColor("#44FF0000")
                }
                style = Paint.Style.FILL
            }

            val screenLeft = ((rect.left - offsetX) * zoom).toFloat()
            val screenTop = ((rect.top - offsetY) * zoom).toFloat()
            val screenRight = ((rect.right - offsetX) * zoom).toFloat()
            val screenBottom = ((rect.bottom - offsetY) * zoom).toFloat()

            canvas.drawRect(screenLeft, screenTop, screenRight, screenBottom, fillPaint)

            zonePaint.color = when (zone.type) {
                MapConfig.ZoneType.SPAWN -> Color.parseColor("#FFAA00")
                MapConfig.ZoneType.CAPTURE -> Color.parseColor("#FF4444")
                MapConfig.ZoneType.RESOURCE -> Color.parseColor("#44FF44")
                MapConfig.ZoneType.RESTRICTED -> Color.parseColor("#FF0000")
            }
            canvas.drawRect(screenLeft, screenTop, screenRight, screenBottom, zonePaint)

            val centerX = (screenLeft + screenRight) / 2f
            val centerY = (screenTop + screenBottom) / 2f
            val label = if (zone.type == MapConfig.ZoneType.SPAWN) "🏠 ${zone.name}" else zone.name
            canvas.drawText(label, centerX, centerY + 7f, labelPaint)
        }
    }

    private fun drawLoadingScreen(canvas: Canvas) {
        val gradientPaint = Paint().apply {
            shader = android.graphics.LinearGradient(
                0f, 0f,
                0f, canvas.height.toFloat(),
                Color.parseColor("#1a2233"),
                Color.parseColor("#2a3a4a"),
                android.graphics.Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), gradientPaint)

        val centerX = canvas.width / 2f
        val centerY = canvas.height / 2f

        val currentTime = System.currentTimeMillis()
        if (currentTime - lastUpdateTime > 400) {
            dotCount = (dotCount % 3) + 1
            lastUpdateTime = currentTime
        }

        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 40f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        canvas.drawText("ЗАГРУЗКА", centerX, centerY - 120f, titlePaint)

        val textPaint = Paint().apply {
            color = Color.parseColor("#8a9aaa")
            textSize = 24f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val dots = ".".repeat(dotCount)
        canvas.drawText("$loadingText$dots", centerX, centerY - 60f, textPaint)

        val barWidth = canvas.width * 0.6f
        val barHeight = 20f
        val barX = (canvas.width - barWidth) / 2f
        val barY = centerY - 20f

        val bgPaint = Paint().apply {
            color = Color.parseColor("#3a4050")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(barX, barY, barX + barWidth, barY + barHeight, 10f, 10f, bgPaint)

        val progressPaint = Paint().apply {
            color = Color.parseColor("#4CAF50")
            style = Paint.Style.FILL
        }
        val progressWidth = (barWidth * loadingProgress).coerceAtLeast(0f)
        if (progressWidth > 0) {
            canvas.drawRoundRect(barX, barY, barX + progressWidth, barY + barHeight, 10f, 10f, progressPaint)
        }

        val percentPaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        canvas.drawText("${(loadingProgress * 100).toInt()}%", centerX, barY + barHeight + 35f, percentPaint)
    }

    private fun drawDebugInfo(canvas: Canvas) {
        val debugPaint = Paint().apply {
            color = Color.WHITE
            textSize = 14f
            isAntiAlias = true
            typeface = Typeface.create("monospace", Typeface.NORMAL)
            textAlign = Paint.Align.LEFT
        }

        val bgPaint = Paint().apply {
            color = Color.parseColor("#cc000000")
            style = Paint.Style.FILL
        }

        val info = mutableListOf(
            "📊 СТАТИСТИКА",
            "  Размер: ${tileMap.width}x${tileMap.height}",
            "  Чанков: ${mapRenderer.getChunksCached()} закешировано",
            "  Видимых: ${mapRenderer.chunksRendered}",
            "  Время рендера: ${mapRenderer.renderTime}ms",
            "",
            "🎮 УПРАВЛЕНИЕ",
            "  Зум: ${"%.2f".format(zoom)}x",
            "  Оффсет: (${offsetX.toInt()}, ${offsetY.toInt()})"
        )

        val padding = 10f
        var y = 70f
        val maxWidth = info.maxOf { debugPaint.measureText(it) }
        val totalHeight = info.size * 22f + padding * 2

        canvas.drawRoundRect(12f, 60f, 12f + maxWidth + padding * 2, 60f + totalHeight, 8f, 8f, bgPaint)

        info.forEach { text ->
            if (text.startsWith("📊") || text.startsWith("🎮")) {
                val boldPaint = Paint().apply {
                    color = Color.parseColor("#4CAF50")
                    textSize = 15f
                    isAntiAlias = true
                    typeface = Typeface.create("monospace", Typeface.BOLD)
                    textAlign = Paint.Align.LEFT
                }
                canvas.drawText(text, 12f + padding, y, boldPaint)
            } else if (text.startsWith("  ")) {
                val grayPaint = Paint().apply {
                    color = Color.parseColor("#aaaaaa")
                    textSize = 13f
                    isAntiAlias = true
                    typeface = Typeface.create("monospace", Typeface.NORMAL)
                    textAlign = Paint.Align.LEFT
                }
                canvas.drawText(text, 12f + padding, y, grayPaint)
            } else {
                canvas.drawText(text, 12f + padding, y, debugPaint)
            }
            y += 22f
        }
    }

    fun update(deltaTime: Float) {}

    fun handleTouch(event: MotionEvent): Boolean {
        if (isLoading) return true
        return touchHandler.handleTouch(event)
    }

    fun resize(width: Int, height: Int) {
        viewport = Rect(0, 0, width, height)
        if (isInitialized) {
            clampOffset()
            updateViewport()
        }
    }

    private fun updateViewport() {
        if (!isInitialized) return

        val viewW = viewport.width() / zoom
        val viewH = viewport.height() / zoom

        val left = kotlin.math.floor(offsetX.toDouble()).toInt()
        val top = kotlin.math.floor(offsetY.toDouble()).toInt()
        val right = kotlin.math.ceil((offsetX + viewW).toDouble()).toInt()
        val bottom = kotlin.math.ceil((offsetY + viewH).toDouble()).toInt()

        val worldViewport = Rect(left, top, right, bottom)

        mapRenderer.setViewport(worldViewport)
        mapRenderer.setZoom(zoom)
        mapRenderer.setOffset(offsetX, offsetY)
    }

    fun release() {
        if (::tileAtlas.isInitialized) tileAtlas.release()
        if (::mapRenderer.isInitialized) mapRenderer.release()
    }

    fun isLoading(): Boolean = isLoading
    fun getZoom(): Float = zoom
    fun getWorldX(screenX: Float): Float = screenX / zoom + offsetX
    fun getWorldY(screenY: Float): Float = screenY / zoom + offsetY
    fun getScreenX(worldX: Float): Float = (worldX - offsetX) * zoom
    fun getScreenY(worldY: Float): Float = (worldY - offsetY) * zoom
}