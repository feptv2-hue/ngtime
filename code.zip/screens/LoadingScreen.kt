package com.example.hhh.game.screens

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import com.example.hhh.game.config.MenuConfig

class LoadingScreen {
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 60f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private var dotCount = 1
    private var lastUpdateTime = 0L

    fun update(currentTime: Long) {
        if (currentTime - lastUpdateTime > MenuConfig.LOADING_DELAY_MS) {
            dotCount = (dotCount % 3) + 1
            lastUpdateTime = currentTime
        }
    }

    fun draw(canvas: Canvas, screenWidth: Int, screenHeight: Int) {
        // Серо-синий фон как в War Thunder
        val gradientPaint = Paint().apply {
            shader = android.graphics.LinearGradient(
                0f, 0f,
                0f, screenHeight.toFloat(),
                MenuConfig.BACKGROUND_TOP,
                MenuConfig.BACKGROUND_BOTTOM,
                android.graphics.Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), screenHeight.toFloat(), gradientPaint)

        // Текст "ЗАГРУЗКА" с точками
        val dots = ".".repeat(dotCount)
        val text = "${MenuConfig.LOADING_TEXT}$dots"

        canvas.drawText(
            text,
            screenWidth / 2f,
            screenHeight / 2f,
            textPaint
        )
    }
}