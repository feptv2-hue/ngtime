package com.example.hhh.game.screens

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.hhh.game.config.UnitData
import com.example.hhh.game.config.UnitType

class SlotSelectionScreen(
    private val onSlotSelected: (Int) -> Unit
) {
    private val dimPaint = Paint().apply {
        color = Color.parseColor("#cc000000")
    }

    private val slotPaint = Paint().apply {
        color = Color.parseColor("#2a3545")
        style = Paint.Style.FILL
    }

    private val slotBorderPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val slotOccupiedPaint = Paint().apply {
        color = Color.parseColor("#3a5a4a")
        style = Paint.Style.FILL
    }

    private val slotOccupiedBorderPaint = Paint().apply {
        color = Color.parseColor("#6a9a7a")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val slotTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val slotSubTextPaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 16f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    private val slotUnitNamePaint = Paint().apply {
        color = Color.WHITE
        textSize = 14f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    private val titlePaint = Paint().apply {
        color = Color.WHITE
        textSize = 32f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val cancelPaint = Paint().apply {
        color = Color.parseColor("#ff4444")
        style = Paint.Style.FILL
    }

    private val cancelTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 20f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val occupiedLabelPaint = Paint().apply {
        color = Color.parseColor("#6a9a7a")
        textSize = 12f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val emptyLabelPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        textSize = 12f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    private var slotRects: List<RectF> = emptyList()
    private var cancelRect: RectF? = null
    private var isVisible = false
    private var selectedUnit: UnitData? = null
    private var slotUnits: List<UnitData?> = emptyList()
    private var screenWidth = 0
    private var screenHeight = 0

    fun show(unit: UnitData, slots: List<UnitData?>) {
        selectedUnit = unit
        slotUnits = slots
        isVisible = true
    }

    fun hide() {
        isVisible = false
        selectedUnit = null
    }

    fun isVisible(): Boolean = isVisible

    fun updateSlots(slots: List<UnitData?>) {
        slotUnits = slots
    }

    fun initialize(screenWidth: Int, screenHeight: Int) {
        this.screenWidth = screenWidth
        this.screenHeight = screenHeight

        val slotSize = screenWidth * 0.12f
        val spacing = screenWidth * 0.03f
        val totalWidth = slotSize * 5 + spacing * 4
        val startX = (screenWidth - totalWidth) / 2f
        val startY = (screenHeight - slotSize) / 2f

        slotRects = (0 until 5).map { index ->
            RectF(
                startX + index * (slotSize + spacing),
                startY,
                startX + index * (slotSize + spacing) + slotSize,
                startY + slotSize
            )
        }

        val cancelWidth = screenWidth * 0.15f
        val cancelHeight = 50f
        cancelRect = RectF(
            (screenWidth - cancelWidth) / 2f,
            startY + slotSize + 40f,
            (screenWidth + cancelWidth) / 2f,
            startY + slotSize + 40f + cancelHeight
        )
    }

    fun handleClick(x: Float, y: Float): Boolean {
        if (!isVisible) return false

        slotRects.forEachIndexed { index, rect ->
            if (rect.contains(x, y)) {
                onSlotSelected(index)
                hide()
                return true
            }
        }

        cancelRect?.let { rect ->
            if (rect.contains(x, y)) {
                hide()
                return true
            }
        }

        hide()
        return true
    }

    fun draw(canvas: Canvas) {
        if (!isVisible) return

        canvas.drawRect(0f, 0f, screenWidth.toFloat(), screenHeight.toFloat(), dimPaint)

        val titleY = screenHeight * 0.22f
        canvas.drawText(
            "ВЫБЕРИТЕ СЛОТ ДЛЯ ТЕХНИКИ",
            screenWidth / 2f,
            titleY,
            titlePaint
        )

        val unitNamePaint = Paint().apply {
            color = Color.parseColor("#8a9aaa")
            textSize = 20f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        selectedUnit?.let { unit ->
            canvas.drawText(unit.name, screenWidth / 2f, titleY + 35f, unitNamePaint)
        }

        val hintPaint = Paint().apply {
            color = Color.parseColor("#4a5a6a")
            textSize = 14f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(
            "Нажмите на слот для установки техники",
            screenWidth / 2f,
            titleY + 60f,
            hintPaint
        )

        slotRects.forEachIndexed { index, rect ->
            val isOccupied = slotUnits.getOrNull(index) != null
            val unitInSlot = slotUnits.getOrNull(index)

            val bgPaint = if (isOccupied) slotOccupiedPaint else slotPaint
            val borderPaint = if (isOccupied) slotOccupiedBorderPaint else slotBorderPaint

            canvas.drawRoundRect(rect, 8f, 8f, bgPaint)
            canvas.drawRoundRect(rect, 8f, 8f, borderPaint)

            if (isOccupied && unitInSlot != null) {
                val iconSize = rect.width() * 0.25f
                val iconX = rect.centerX()
                val iconY = rect.centerY() - 8f

                val iconPaint = Paint().apply {
                    color = Color.parseColor("#3a4050")
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(iconX, iconY, iconSize, iconPaint)

                val iconTextPaint = Paint().apply {
                    color = Color.parseColor("#8a9aaa")
                    textSize = 16f
                    isAntiAlias = true
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
                val typeLetter = when (unitInSlot.type) {
                    UnitType.GROUND -> "Т"
                    UnitType.INFANTRY -> "П"
                    UnitType.AVIATION -> "А"
                }
                canvas.drawText(typeLetter, iconX, iconY + 6f, iconTextPaint)

                canvas.drawText(
                    unitInSlot.name,
                    rect.centerX(),
                    rect.bottom - 20f,
                    slotUnitNamePaint
                )

                canvas.drawText(
                    "ЗАНЯТ",
                    rect.centerX(),
                    rect.top + 18f,
                    occupiedLabelPaint
                )
            } else {
                canvas.drawText(
                    "${index + 1}",
                    rect.centerX(),
                    rect.centerY() - 10f,
                    slotTextPaint
                )

                canvas.drawText(
                    "СЛОТ",
                    rect.centerX(),
                    rect.centerY() + 25f,
                    slotSubTextPaint
                )

                canvas.drawText(
                    "СВОБОДЕН",
                    rect.centerX(),
                    rect.top + 18f,
                    emptyLabelPaint
                )
            }
        }

        cancelRect?.let { rect ->
            canvas.drawRoundRect(rect, 6f, 6f, cancelPaint)
            canvas.drawText(
                "ОТМЕНА",
                rect.centerX(),
                rect.centerY() + 7f,
                cancelTextPaint
            )
        }
    }
}