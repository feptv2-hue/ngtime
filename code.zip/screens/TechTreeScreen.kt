package com.example.hhh.game.screens

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.Path
import android.view.MotionEvent
import com.example.hhh.game.config.UnitsConfig
import com.example.hhh.game.config.UnitData
import com.example.hhh.game.config.UnitType
import com.example.hhh.game.config.UnitClass
import com.example.hhh.game.config.UnitStatsConfig

class TechTreeScreen(
    private val onClose: () -> Unit = {},
    private val onSelectCrew: (UnitData) -> Unit = {}
) {
    // === ФОН ОКНА ===
    private val windowPaint = Paint().apply {
        color = Color.parseColor("#1a2233")
        style = Paint.Style.FILL
    }

    private val windowBorderPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    // === ЗАГОЛОВОК ===
    private val titlePaint = Paint().apply {
        color = Color.WHITE
        textSize = 28f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === КНОПКИ ТИПОВ ===
    private val typeButtonPaint = Paint().apply {
        color = Color.parseColor("#3a4050")
        style = Paint.Style.FILL
    }

    private val typeButtonSelectedPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.FILL
    }

    private val typeButtonStrokePaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val typeTextPaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 22f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val typeTextSelectedPaint = Paint().apply {
        color = Color.WHITE
        textSize = 22f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === КНОПКА ЗАКРЫТИЯ ===
    private val closeButtonPaint = Paint().apply {
        color = Color.parseColor("#ff4444")
        style = Paint.Style.FILL
    }

    private val closeTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 28f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === ЮНИТЫ ===
    private val unitSlotPaint = Paint().apply {
        color = Color.parseColor("#2a3545")
        style = Paint.Style.FILL
    }

    private val unitSlotBorderPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val unitSlotSelectedPaint = Paint().apply {
        color = Color.parseColor("#3a5a4a")
        style = Paint.Style.FILL
    }

    private val unitNamePaint = Paint().apply {
        color = Color.WHITE
        textSize = 14f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val unitTierPaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 12f
        isAntiAlias = true
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    // === ТЕКСТ ЗАГРУЗКИ ===
    private val loadingTextPaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 32f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val loadingDotsPaint = Paint().apply {
        color = Color.WHITE
        textSize = 32f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === ЛИНИИ СОЕДИНЕНИЯ ===
    private val linePaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    // === НАЗВАНИЯ КЛАССОВ ===
    private val classTitlePaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 16f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === ПАНЕЛЬ ИНФОРМАЦИИ ===
    private val infoPanelPaint = Paint().apply {
        color = Color.parseColor("#1a2a3a")
        style = Paint.Style.FILL
    }

    private val infoPanelBorderPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val infoTitlePaint = Paint().apply {
        color = Color.WHITE
        textSize = 18f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val infoTextPaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 15f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val infoValuePaint = Paint().apply {
        color = Color.WHITE
        textSize = 15f
        isAntiAlias = true
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val weaponIconPaint = Paint().apply {
        textSize = 28f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    private val weaponNamePaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 10f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    // === ПАНЕЛЬ ДЕЙСТВИЙ ===
    private val actionButtonPaint = Paint().apply {
        color = Color.parseColor("#3a4050")
        style = Paint.Style.FILL
    }

    private val actionButtonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 14f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    // === СОСТОЯНИЕ ===
    private var currentNation = "РОССИЯ"
    private var currentType = UnitType.GROUND
    private var isVisible = false
    private var isLoading = false
    private var selectedUnitId: String? = null

    // === СКРОЛЛ ===
    private var scrollOffset = 0f
    private var maxScroll = 0f
    private var isDragging = false
    private var lastTouchY = 0f

    // === РАЗМЕРЫ ===
    private var screenWidth = 0
    private var screenHeight = 0

    // === ДАННЫЕ ===
    data class TypeButton(
        val rect: RectF,
        val type: UnitType,
        val text: String
    )

    data class UnitSlot(
        val rect: RectF,
        val unit: UnitData,
        val classIndex: Int,
        val indexInClass: Int
    )

    data class ClassColumn(
        val classType: UnitClass,
        val units: List<UnitData>,
        val x: Float,
        val width: Float
    )

    private var typeButtons: List<TypeButton> = emptyList()
    private var classColumns: List<ClassColumn> = emptyList()
    private var unitSlots: List<UnitSlot> = emptyList()
    private var windowRect: RectF? = null
    private var closeButtonRect: RectF? = null
    private var contentRect: RectF? = null

    // Кнопки в панели действий
    private var selectCrewButtonRect: RectF? = null
    private var weaponStatsButtonRect: RectF? = null

    // === АНИМАЦИЯ ЗАГРУЗКИ ===
    private var dotCount = 1
    private var lastUpdateTime = 0L
    private val loadingDelay = 400L

    // === ПУБЛИЧНЫЕ МЕТОДЫ ===

    fun show(nation: String) {
        currentNation = nation
        isVisible = true
        isLoading = true
        scrollOffset = 0f
        selectedUnitId = null

        val types = UnitsConfig.getUnitTypes(nation)
        if (types.isNotEmpty()) {
            currentType = types.first()
        }

        updateData()

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            isLoading = false
            windowRect?.let { rect ->
                updatePositions(rect.left, rect.top, rect.width(), rect.height())
            }
        }, 1500)
    }

    fun hide() {
        isVisible = false
        isLoading = false
        selectedUnitId = null
        onClose()
    }

    fun isVisible(): Boolean = isVisible

    fun getSelectedUnit(): UnitData? {
        return unitSlots.find { it.unit.id == selectedUnitId }?.unit
    }

    // === ПРИВАТНЫЕ МЕТОДЫ ===

    private fun updateData() {
        val classes = UnitsConfig.getUnitClasses(currentNation, currentType)
        classColumns = classes.map { classType ->
            val units = UnitsConfig.getUnitsByClass(currentNation, currentType, classType)
            ClassColumn(classType, units, 0f, 0f)
        }
    }

    fun initialize(screenWidth: Int, screenHeight: Int) {
        this.screenWidth = screenWidth
        this.screenHeight = screenHeight

        val windowWidth = screenWidth * 0.9f
        val windowHeight = screenHeight * 0.85f
        val windowX = (screenWidth - windowWidth) / 2f
        val windowY = (screenHeight - windowHeight) / 2f

        windowRect = RectF(windowX, windowY, windowX + windowWidth, windowY + windowHeight)

        val contentTop = windowY + 140f
        val contentBottom = windowY + windowHeight - 20f
        contentRect = RectF(windowX + 20f, contentTop, windowX + windowWidth - 20f, contentBottom)

        val closeSize = 44f
        closeButtonRect = RectF(
            windowX + windowWidth - closeSize - 12f,
            windowY + 12f,
            windowX + windowWidth - 12f,
            windowY + 12f + closeSize
        )

        val typeNames = listOf(
            UnitType.GROUND to "НАЗЕМНЫЕ",
            UnitType.INFANTRY to "ПЕХОТА",
            UnitType.AVIATION to "АВИАЦИЯ"
        )

        val buttonWidth = windowWidth * 0.22f
        val buttonHeight = 52f
        val spacing = windowWidth * 0.02f
        val totalWidth = buttonWidth * typeNames.size + spacing * (typeNames.size - 1)
        val startX = windowX + (windowWidth - totalWidth) / 2f
        val buttonY = windowY + 65f

        typeButtons = typeNames.mapIndexed { index, (type, text) ->
            TypeButton(
                rect = RectF(
                    startX + index * (buttonWidth + spacing),
                    buttonY,
                    startX + index * (buttonWidth + spacing) + buttonWidth,
                    buttonY + buttonHeight
                ),
                type = type,
                text = text
            )
        }

        updateData()
        updatePositions(windowX, windowY, windowWidth, windowHeight)
    }

    private fun updatePositions(windowX: Float, windowY: Float, windowWidth: Float, windowHeight: Float) {
        contentRect?.let { content ->
            val contentTop = content.top
            val contentBottom = content.bottom
            val contentHeight = contentBottom - contentTop

            val slotWidth = 130f
            val slotHeight = 75f
            val slotSpacing = 28f
            val classSpacing = 55f

            val visibleClasses = classColumns.filter { it.units.isNotEmpty() }
            if (visibleClasses.isEmpty()) {
                unitSlots = emptyList()
                maxScroll = 0f
                return
            }

            val maxUnitsInClass = visibleClasses.maxOfOrNull { it.units.size } ?: 0
            val totalHeight = maxUnitsInClass * (slotHeight + slotSpacing) + 40f

            maxScroll = maxOf(0f, totalHeight - contentHeight)

            val totalWidth = visibleClasses.size * (slotWidth + classSpacing) - classSpacing
            val startX = content.left + (content.width() - totalWidth) / 2f

            val updatedColumns = visibleClasses.mapIndexed { index, column ->
                column.copy(
                    x = startX + index * (slotWidth + classSpacing),
                    width = slotWidth
                )
            }
            classColumns = updatedColumns

            val newSlots = mutableListOf<UnitSlot>()
            updatedColumns.forEachIndexed { classIndex, column ->
                column.units.forEachIndexed { unitIndex, unit ->
                    val y = contentTop - scrollOffset + unitIndex * (slotHeight + slotSpacing) + 25f
                    newSlots.add(
                        UnitSlot(
                            rect = RectF(
                                column.x,
                                y,
                                column.x + slotWidth,
                                y + slotHeight
                            ),
                            unit = unit,
                            classIndex = classIndex,
                            indexInClass = unitIndex
                        )
                    )
                }
            }
            unitSlots = newSlots
        }
    }

    // === ОБРАБОТКА КЛИКОВ ===

    fun handleClick(x: Float, y: Float): Boolean {
        if (!isVisible) return false

        closeButtonRect?.let { rect ->
            if (rect.contains(x, y)) {
                hide()
                return true
            }
        }

        if (isLoading) return false

        typeButtons.forEach { button ->
            if (button.rect.contains(x, y)) {
                if (currentType == button.type) return true

                currentType = button.type
                isLoading = true
                scrollOffset = 0f
                selectedUnitId = null

                updateData()

                windowRect?.let { rect ->
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        isLoading = false
                        updatePositions(rect.left, rect.top, rect.width(), rect.height())
                    }, 800)
                }
                return true
            }
        }

        // Проверяем клик по кнопке "Выбрать экипаж"
        selectCrewButtonRect?.let { rect ->
            if (rect.contains(x, y)) {
                val unit = getSelectedUnit()
                if (unit != null) {
                    onSelectCrew(unit)
                    return true
                }
            }
        }

        // Проверяем клик по кнопке "Характеристика вооружения"
        weaponStatsButtonRect?.let { rect ->
            if (rect.contains(x, y)) {
                println("📊 Характеристика вооружения")
                return true
            }
        }

        // Проверяем клик по пустому месту
        windowRect?.let { window ->
            if (x < window.left || x > window.right || y < window.top || y > window.bottom) {
                selectedUnitId = null
                return true
            }
        }

        // Проверяем клик по юниту
        var clickedUnit = false
        unitSlots.forEach { slot ->
            if (slot.rect.contains(x, y)) {
                contentRect?.let { content ->
                    if (slot.rect.top >= content.top && slot.rect.bottom <= content.bottom) {
                        selectedUnitId = if (selectedUnitId == slot.unit.id) null else slot.unit.id
                        clickedUnit = true
                    }
                }
            }
        }

        if (clickedUnit) return true

        // Если клик по пустому месту в области контента - снимаем выбор
        contentRect?.let { content ->
            if (x >= content.left && x <= content.right &&
                y >= content.top && y <= content.bottom) {
                var hitSlot = false
                unitSlots.forEach { slot ->
                    if (slot.rect.contains(x, y)) {
                        hitSlot = true
                    }
                }
                if (!hitSlot) {
                    selectedUnitId = null
                    return true
                }
            }
        }

        return false
    }

    fun handleTouch(event: MotionEvent): Boolean {
        if (!isVisible || isLoading) return false

        contentRect?.let { content ->
            val x = event.x
            val y = event.y
            if (x < content.left || x > content.right || y < content.top || y > content.bottom) {
                return false
            }
        }

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                isDragging = true
                lastTouchY = event.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDragging) {
                    val deltaY = lastTouchY - event.y
                    scrollOffset = (scrollOffset + deltaY).coerceIn(0f, maxScroll)
                    lastTouchY = event.y

                    windowRect?.let { rect ->
                        updatePositions(rect.left, rect.top, rect.width(), rect.height())
                    }
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                isDragging = false
                return true
            }
        }
        return false
    }

    // === ОТРИСОВКА ===

    fun draw(canvas: Canvas) {
        if (!isVisible) return

        // Затемнение фона
        val dimPaint = Paint().apply {
            color = Color.parseColor("#aa000000")
        }
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), dimPaint)

        windowRect?.let { rect ->
            // Окно
            canvas.drawRoundRect(rect, 12f, 12f, windowPaint)
            canvas.drawRoundRect(rect, 12f, 12f, windowBorderPaint)

            // Заголовок
            canvas.drawText(
                "ДРЕВО ТЕХНОЛОГИЙ - $currentNation",
                rect.centerX(),
                rect.top + 40f,
                titlePaint
            )

            // Кнопка закрытия
            closeButtonRect?.let { closeRect ->
                canvas.drawRoundRect(closeRect, 6f, 6f, closeButtonPaint)
                canvas.drawText(
                    "✕",
                    closeRect.centerX(),
                    closeRect.centerY() + 10f,
                    closeTextPaint
                )
            }

            // Кнопки типов
            typeButtons.forEach { button ->
                val isSelected = button.type == currentType
                val paint = if (isSelected) typeButtonSelectedPaint else typeButtonPaint
                canvas.drawRoundRect(button.rect, 6f, 6f, paint)
                canvas.drawRoundRect(button.rect, 6f, 6f, typeButtonStrokePaint)

                val textPaint = if (isSelected) typeTextSelectedPaint else typeTextPaint
                canvas.drawText(
                    button.text,
                    button.rect.centerX(),
                    button.rect.centerY() + 8f,
                    textPaint
                )
            }

            // Загрузка
            if (isLoading) {
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastUpdateTime > loadingDelay) {
                    dotCount = (dotCount % 3) + 1
                    lastUpdateTime = currentTime
                }

                val dots = ".".repeat(dotCount)
                val centerX = rect.centerX()
                val centerY = rect.centerY() + 20f

                val loadingText = "ЗАГРУЗКА"
                val textWidth = loadingTextPaint.measureText(loadingText)
                val totalWidth = textWidth + loadingDotsPaint.measureText(dots)
                val startX = centerX - totalWidth / 2f

                canvas.drawText(loadingText, startX, centerY, loadingTextPaint)
                canvas.drawText(dots, startX + textWidth, centerY, loadingDotsPaint)
                return
            }

            // === ОТРИСОВКА ДРЕВА ===
            contentRect?.let { content ->
                canvas.save()

                val clipPath = Path().apply {
                    addRect(content.left, content.top, content.right, content.bottom, Path.Direction.CW)
                }
                canvas.clipPath(clipPath)

                // Заголовки классов и линии
                classColumns.forEachIndexed { index, column ->
                    if (column.units.isNotEmpty()) {
                        val titleY = content.top + 15f
                        val className = UnitsConfig.getClassName(column.classType)
                        canvas.drawText(
                            className,
                            column.x + column.width / 2f,
                            titleY,
                            classTitlePaint
                        )

                        // Вертикальная линия только до последнего юнита
                        val firstUnitY = content.top + 40f
                        val lastUnitIndex = column.units.size - 1
                        val lastUnitY = content.top - scrollOffset + lastUnitIndex * (75f + 28f) + 25f + 75f
                        val endY = minOf(lastUnitY, content.bottom - 10f)

                        if (endY > firstUnitY) {
                            val lineX = column.x + column.width / 2f
                            canvas.drawLine(
                                lineX, firstUnitY,
                                lineX, endY,
                                linePaint
                            )
                        }

                        // Горизонтальные линии к слотам
                        unitSlots.filter { it.classIndex == index }.forEach { slot ->
                            val centerY = slot.rect.centerY()
                            val lineX = column.x + column.width / 2f
                            val lineEndX = slot.rect.left + 8f

                            if (centerY >= content.top && centerY <= content.bottom) {
                                canvas.drawLine(
                                    lineX, centerY,
                                    lineEndX, centerY,
                                    linePaint
                                )

                                val nodePaint = Paint().apply {
                                    color = Color.parseColor("#4a5a6a")
                                    style = Paint.Style.FILL
                                }
                                canvas.drawCircle(lineX, centerY, 4f, nodePaint)
                            }
                        }
                    }
                }

                // Слоты юнитов
                unitSlots.forEach { slot ->
                    if (slot.rect.top >= content.top - slot.rect.height() &&
                        slot.rect.bottom <= content.bottom + slot.rect.height()) {

                        val isSelected = slot.unit.id == selectedUnitId
                        val paint = if (isSelected) unitSlotSelectedPaint else unitSlotPaint

                        // Прямоугольная плашка
                        canvas.drawRect(slot.rect, paint)
                        canvas.drawRect(slot.rect, unitSlotBorderPaint)

                        // Иконка
                        val iconSize = slot.rect.height() * 0.28f
                        val iconX = slot.rect.left + slot.rect.height() * 0.25f
                        val iconY = slot.rect.centerY()

                        val iconBgPaint = Paint().apply {
                            color = Color.parseColor("#3a4050")
                            style = Paint.Style.FILL
                        }
                        canvas.drawCircle(iconX, iconY, iconSize, iconBgPaint)

                        val iconTextPaint = Paint().apply {
                            color = Color.parseColor("#8a9aaa")
                            textSize = 16f
                            isAntiAlias = true
                            textAlign = Paint.Align.CENTER
                            typeface = Typeface.create("sans-serif", Typeface.BOLD)
                        }
                        val typeLetter = when (slot.unit.type) {
                            UnitType.GROUND -> "Т"
                            UnitType.INFANTRY -> "П"
                            UnitType.AVIATION -> "А"
                        }
                        canvas.drawText(typeLetter, iconX, iconY + 6f, iconTextPaint)

                        // Название
                        val textX = slot.rect.left + slot.rect.height() * 0.5f + 8f
                        canvas.drawText(
                            slot.unit.name,
                            textX,
                            slot.rect.top + 22f,
                            unitNamePaint
                        )

                        // Тир
                        canvas.drawText(
                            "Тир ${slot.unit.tier}",
                            slot.rect.right - 8f,
                            slot.rect.bottom - 8f,
                            unitTierPaint
                        )
                    }
                }

                canvas.restore()
            }

            // === ПАНЕЛИ ИНФОРМАЦИИ ===
            if (selectedUnitId != null) {
                val stats = UnitStatsConfig.getStats(selectedUnitId!!)
                if (stats != null) {
                    val topOffset = rect.top + 170f

                    // Левая панель
                    val infoPanelWidth = rect.width() * 0.2f
                    val infoPanelX = rect.left + 10f
                    val infoPanelBottom = rect.bottom - 20f

                    canvas.drawRect(
                        infoPanelX, topOffset,
                        infoPanelX + infoPanelWidth, infoPanelBottom,
                        infoPanelPaint
                    )
                    canvas.drawRect(
                        infoPanelX, topOffset,
                        infoPanelX + infoPanelWidth, infoPanelBottom,
                        infoPanelBorderPaint
                    )

                    drawInfoPanel(
                        canvas,
                        RectF(infoPanelX, topOffset, infoPanelX + infoPanelWidth, infoPanelBottom),
                        selectedUnitId!!
                    )

                    // Правая панель
                    val actionPanelWidth = rect.width() * 0.12f
                    val actionPanelX = rect.right - actionPanelWidth - 10f

                    canvas.drawRect(
                        actionPanelX, topOffset,
                        actionPanelX + actionPanelWidth, infoPanelBottom,
                        infoPanelPaint
                    )
                    canvas.drawRect(
                        actionPanelX, topOffset,
                        actionPanelX + actionPanelWidth, infoPanelBottom,
                        infoPanelBorderPaint
                    )

                    drawActionPanel(
                        canvas,
                        RectF(actionPanelX, topOffset, actionPanelX + actionPanelWidth, infoPanelBottom)
                    )
                }
            }

            // Индикатор скролла
            contentRect?.let { content ->
                if (maxScroll > 0) {
                    val scrollBarWidth = 6f
                    val scrollBarHeight = content.height() * 0.3f
                    val scrollBarX = rect.right - 14f
                    val scrollProgress = scrollOffset / maxScroll
                    val scrollBarY = content.top + (content.height() - scrollBarHeight) * scrollProgress

                    val scrollBarPaint = Paint().apply {
                        color = Color.parseColor("#4a5a6a")
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(
                        scrollBarX, scrollBarY,
                        scrollBarX + scrollBarWidth, scrollBarY + scrollBarHeight,
                        3f, 3f, scrollBarPaint
                    )
                }
            }
        }
    }

    // === ОТРИСОВКА ПАНЕЛИ ИНФОРМАЦИИ ===

    private fun drawInfoPanel(canvas: Canvas, rect: RectF, unitId: String) {
        val stats = UnitStatsConfig.getStats(unitId)
        if (stats == null) {
            canvas.drawText("НЕТ ДАННЫХ", rect.centerX(), rect.centerY(), infoTextPaint)
            return
        }

        val panelWidth = rect.width()
        val padding = 12f
        var currentY = rect.top + 15f

        // Иконка
        val iconSize = 32f
        val iconX = rect.left + panelWidth / 2f
        canvas.drawCircle(iconX, currentY + iconSize / 2f, iconSize / 2f, unitSlotPaint)
        canvas.drawCircle(iconX, currentY + iconSize / 2f, iconSize / 2f, unitSlotBorderPaint)

        val typeLetter = when (stats.type) {
            UnitType.GROUND -> "Т"
            UnitType.INFANTRY -> "П"
            UnitType.AVIATION -> "А"
        }
        val iconTextPaint = Paint().apply {
            color = Color.parseColor("#8a9aaa")
            textSize = 16f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        canvas.drawText(typeLetter, iconX, currentY + iconSize / 2f + 5f, iconTextPaint)

        currentY += iconSize + 10f

        // Название
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 16f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        canvas.drawText(stats.name, rect.centerX(), currentY, titlePaint)
        currentY += 22f

        // Характеристики
        val statsList = listOf(
            "Огневая мощь" to stats.firepower,
            "Броня" to stats.armor,
            "Мобильность" to stats.mobility,
            "Дальность" to stats.range,
            "Точность" to stats.accuracy
        )

        statsList.forEach { (name, value) ->
            canvas.drawText(name, rect.left + padding, currentY, infoTextPaint)
            canvas.drawText("$value", rect.right - padding, currentY, infoValuePaint)
            currentY += 20f
        }

        currentY += 6f

        // Типы вооружения
        val remainingHeight = rect.bottom - currentY - 10f
        if (remainingHeight > 35f && stats.weapons.isNotEmpty()) {
            val weaponStartY = currentY
            val weaponSpacing = panelWidth / stats.weapons.size

            stats.weapons.forEachIndexed { index, weapon ->
                val x = rect.left + padding + index * weaponSpacing + weaponSpacing / 2f
                val icon = UnitStatsConfig.getWeaponIcon(weapon)
                canvas.drawText(icon, x, weaponStartY + 16f, weaponIconPaint)

                val name = UnitStatsConfig.getWeaponName(weapon)
                val namePaint = Paint().apply {
                    color = Color.parseColor("#8a9aaa")
                    textSize = 10f
                    isAntiAlias = true
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                }
                canvas.drawText(name, x, weaponStartY + 34f, namePaint)
            }
        }
    }

    // === ОТРИСОВКА ПАНЕЛИ ДЕЙСТВИЙ ===

    private fun drawActionPanel(canvas: Canvas, rect: RectF) {
        val buttonHeight = 38f
        val spacing = 12f
        val startY = rect.top + 30f

        val buttons = listOf("ВЫБРАТЬ ЭКИПАЖ", "ХАРАКТЕРИСТИКА\nВООРУЖЕНИЯ")

        buttons.forEachIndexed { index, text ->
            val y = startY + index * (buttonHeight + spacing)
            val buttonRect = RectF(
                rect.left + 12f,
                y,
                rect.right - 12f,
                y + buttonHeight
            )

            // Сохраняем кнопки для обработки кликов
            if (index == 0) {
                selectCrewButtonRect = buttonRect
            } else {
                weaponStatsButtonRect = buttonRect
            }

            canvas.drawRect(buttonRect, actionButtonPaint)

            val textPaint = Paint().apply {
                color = Color.WHITE
                textSize = 12f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            }

            val lines = text.split("\n")
            if (lines.size == 1) {
                canvas.drawText(text, buttonRect.centerX(), buttonRect.centerY() + 4f, textPaint)
            } else {
                canvas.drawText(lines[0], buttonRect.centerX(), buttonRect.centerY() - 5f, textPaint)
                canvas.drawText(lines[1], buttonRect.centerX(), buttonRect.centerY() + 13f, textPaint)
            }
        }
    }
}