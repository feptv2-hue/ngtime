package com.example.hhh.game.screens

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

class LoginScreen(
    private val onLogin: (String, String) -> Unit,
    private val onRegister: (String, String) -> Unit
) {

    fun getUsername(): String = username
    fun getPassword(): String = password
    fun isLoginMode(): Boolean = isLoginMode

    private val bgPaint = Paint().apply {
        shader = android.graphics.LinearGradient(
            0f, 0f, 0f, 1f,
            Color.parseColor("#1a2233"),
            Color.parseColor("#2a3a4a"),
            android.graphics.Shader.TileMode.CLAMP
        )
    }

    private val titlePaint = Paint().apply {
        color = Color.WHITE
        textSize = 36f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val labelPaint = Paint().apply {
        color = Color.parseColor("#8a9aaa")
        textSize = 16f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
    }

    private val inputBgPaint = Paint().apply {
        color = Color.parseColor("#2a3545")
        style = Paint.Style.FILL
    }

    private val inputBorderPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val inputTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 22f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
    }

    private val buttonLoginPaint = Paint().apply {
        color = Color.parseColor("#4CAF50")
        style = Paint.Style.FILL
    }

    private val buttonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private val errorPaint = Paint().apply {
        color = Color.parseColor("#ff4444")
        textSize = 18f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    private var username = ""
    private var password = ""
    private var isLoginMode = true
    private var errorMessage: String? = null
    private var isLoading = false

    private var usernameRect: RectF? = null
    private var passwordRect: RectF? = null
    private var loginButtonRect: RectF? = null
    private var switchModeRect: RectF? = null
    private var focusedField: String? = null

    fun setLoading(loading: Boolean) {
        isLoading = loading
    }

    fun setError(error: String?) {
        errorMessage = error
    }

    fun setMode(isLogin: Boolean) {
        isLoginMode = isLogin
        errorMessage = null
    }

    fun initialize(screenWidth: Int, screenHeight: Int) {
        val centerX = screenWidth / 2f
        val startY = screenHeight * 0.3f
        val fieldWidth = screenWidth * 0.55f
        val fieldHeight = 50f
        val spacing = 25f

        usernameRect = RectF(
            centerX - fieldWidth / 2f,
            startY,
            centerX + fieldWidth / 2f,
            startY + fieldHeight
        )

        passwordRect = RectF(
            centerX - fieldWidth / 2f,
            startY + fieldHeight + spacing + 15f,
            centerX + fieldWidth / 2f,
            startY + fieldHeight + spacing + 15f + fieldHeight
        )

        val buttonWidth = fieldWidth * 0.65f
        val buttonHeight = 55f
        val buttonY = passwordRect!!.bottom + spacing + 10f

        loginButtonRect = RectF(
            centerX - buttonWidth / 2f,
            buttonY,
            centerX + buttonWidth / 2f,
            buttonY + buttonHeight
        )

        switchModeRect = RectF(
            centerX - 150f,
            buttonY + buttonHeight + spacing,
            centerX + 150f,
            buttonY + buttonHeight + spacing + 40f
        )
    }

    fun handleClick(x: Float, y: Float): Boolean {
        if (isLoading) return true

        usernameRect?.let { rect ->
            if (rect.contains(x, y)) {
                focusedField = "username"
                return true
            }
        }

        passwordRect?.let { rect ->
            if (rect.contains(x, y)) {
                focusedField = "password"
                return true
            }
        }

        loginButtonRect?.let { rect ->
            if (rect.contains(x, y)) {
                focusedField = null // Снимаем фокус с поля
                if (username.isBlank() || password.isBlank()) {
                    errorMessage = "Заполните все поля"
                    return true
                }
                if (isLoginMode) {
                    onLogin(username, password)
                } else {
                    onRegister(username, password)
                }
                return true
            }
        }

        switchModeRect?.let { rect ->
            if (rect.contains(x, y)) {
                isLoginMode = !isLoginMode
                errorMessage = null
                return true
            }
        }

        focusedField = null
        return false
    }

    fun handleKey(char: Char) {
        when (focusedField) {
            "username" -> {
                if (char == '\b') {
                    if (username.isNotEmpty()) username = username.dropLast(1)
                } else if (char.isLetterOrDigit() || char == '_') {
                    username += char
                }
            }
            "password" -> {
                if (char == '\b') {
                    if (password.isNotEmpty()) password = password.dropLast(1)
                } else {
                    password += char
                }
            }
        }
    }

    fun draw(canvas: Canvas, screenWidth: Int, screenHeight: Int) {
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), screenHeight.toFloat(), bgPaint)

        val centerX = screenWidth / 2f

        // Заголовок — Регистрация/Вход
        canvas.drawText(
            if (isLoginMode) "ВХОД" else "РЕГИСТРАЦИЯ",
            centerX,
            screenHeight * 0.18f,
            titlePaint
        )

        val subtitlePaint = Paint().apply {
            color = Color.parseColor("#8a9aaa")
            textSize = 16f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(
            if (isLoginMode) "Войдите в свой аккаунт" else "Создайте новый аккаунт",
            centerX,
            screenHeight * 0.23f,
            subtitlePaint
        )

        // Поле Логин
        usernameRect?.let { rect ->
            canvas.drawText("Логин", rect.left, rect.top - 8f, labelPaint)
            canvas.drawRect(rect, inputBgPaint)
            canvas.drawRect(rect, inputBorderPaint)

            val textX = rect.left + 16f
            val textY = rect.centerY() + 8f
            canvas.drawText(username, textX, textY, inputTextPaint)

            if (username.isEmpty() && focusedField != "username") {
                val hintPaint = Paint().apply {
                    color = Color.parseColor("#4a5a6a")
                    textSize = 22f
                    isAntiAlias = true
                    textAlign = Paint.Align.LEFT
                }
                canvas.drawText("Введите логин", textX, textY, hintPaint)
            }

            if (focusedField == "username") {
                val cursorX = textX + inputTextPaint.measureText(username)
                val cursorPaint = Paint().apply {
                    color = Color.WHITE
                    strokeWidth = 2f
                    style = Paint.Style.STROKE
                }
                canvas.drawLine(cursorX, rect.top + 10f, cursorX, rect.bottom - 10f, cursorPaint)
            }
        }

        // Поле Пароль
        passwordRect?.let { rect ->
            canvas.drawText("Пароль", rect.left, rect.top - 8f, labelPaint)
            canvas.drawRect(rect, inputBgPaint)
            canvas.drawRect(rect, inputBorderPaint)

            val textX = rect.left + 16f
            val textY = rect.centerY() + 8f

            val displayPassword = "*".repeat(password.length)
            canvas.drawText(displayPassword, textX, textY, inputTextPaint)

            if (password.isEmpty() && focusedField != "password") {
                val hintPaint = Paint().apply {
                    color = Color.parseColor("#4a5a6a")
                    textSize = 22f
                    isAntiAlias = true
                    textAlign = Paint.Align.LEFT
                }
                canvas.drawText("Введите пароль", textX, textY, hintPaint)
            }

            if (focusedField == "password") {
                val cursorX = textX + inputTextPaint.measureText(displayPassword)
                val cursorPaint = Paint().apply {
                    color = Color.WHITE
                    strokeWidth = 2f
                    style = Paint.Style.STROKE
                }
                canvas.drawLine(cursorX, rect.top + 10f, cursorX, rect.bottom - 10f, cursorPaint)
            }
        }

        // Кнопка Входа/Регистрации (без скруглений)
        loginButtonRect?.let { rect ->
            canvas.drawRect(rect, buttonLoginPaint)
            val text = if (isLoginMode) "ВОЙТИ" else "ЗАРЕГИСТРИРОВАТЬСЯ"
            canvas.drawText(text, rect.centerX(), rect.centerY() + 9f, buttonTextPaint)
        }

        // Переключение режима
        switchModeRect?.let { rect ->
            val text = if (isLoginMode) "Нет аккаунта? Зарегистрироваться" else "Уже есть аккаунт? Войти"
            val switchPaint = Paint().apply {
                color = Color.parseColor("#4a5a6a")
                textSize = 18f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            }
            canvas.drawText(text, rect.centerX(), rect.centerY() + 12f, switchPaint)
        }

        errorMessage?.let { error ->
            canvas.drawText(error, centerX, screenHeight * 0.87f, errorPaint)
        }

        if (isLoading) {
            val loadPaint = Paint().apply {
                color = Color.WHITE
                textSize = 20f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("Загрузка...", centerX, screenHeight * 0.92f, loadPaint)
        }
    }
}