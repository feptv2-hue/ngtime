package com.example.hhh.game.screens

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.hhh.game.config.MenuConfig
import com.example.hhh.game.config.UnitData
import com.example.hhh.game.config.UnitType

class MainMenuScreen(
    private val onPlayClick: () -> Unit = {},
    private val onOpenTechTree: (String) -> Unit = {},
    private val onLogout: () -> Unit = {}
) {
    // === КНОПКА "ИГРАТЬ" ===
    private val playButtonPaint = Paint().apply {
        color = MenuConfig.BUTTON_PLAY_COLOR
        style = Paint.Style.FILL
    }

    private val playButtonStrokePaint = Paint().apply {
        color = Color.parseColor("#66ffffff")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val playButtonTextPaint = Paint().apply {
        color = MenuConfig.BUTTON_PLAY_TEXT
        textSize = 48f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === ПАНЕЛЬ ВЫБОРА РЕЖИМА ===
    private val modePanelPaint = Paint().apply {
        color = MenuConfig.BUTTON_MODE_COLOR
        style = Paint.Style.FILL
    }

    private val modePanelStrokePaint = Paint().apply {
        color = MenuConfig.BORDER_COLOR
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val modeTextPaint = Paint().apply {
        color = MenuConfig.BUTTON_MODE_TEXT
        textSize = 22f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val modeTextSelectedPaint = Paint().apply {
        color = MenuConfig.BUTTON_MODE_TEXT_SELECTED
        textSize = 22f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === ВЕРХНЯЯ ПАНЕЛЬ С ИНФО ===
    private val topBarPaint = Paint().apply {
        color = MenuConfig.TOP_BAR_COLOR
        style = Paint.Style.FILL
    }

    private val topBarBorderPaint = Paint().apply {
        color = MenuConfig.BORDER_COLOR
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val topBarTextPaint = Paint().apply {
        color = MenuConfig.BAR_TEXT_COLOR
        textSize = 18f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val topBarBoldPaint = Paint().apply {
        color = MenuConfig.TEXT_PRIMARY
        textSize = 18f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === КНОПКА ПРОФИЛЯ (АВАТАР) ===
    private val avatarPaint = Paint().apply {
        color = Color.parseColor("#3a4050")
        style = Paint.Style.FILL
    }

    private val avatarBorderPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val avatarTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 28f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === ВЫПАДАЮЩЕЕ МЕНЮ ===
    private val dropdownBgPaint = Paint().apply {
        color = Color.parseColor("#2a3545")
        style = Paint.Style.FILL
    }

    private val dropdownBorderPaint = Paint().apply {
        color = Color.parseColor("#4a5a6a")
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val logoutButtonPaint = Paint().apply {
        color = Color.parseColor("#cc3333")
        style = Paint.Style.FILL
    }

    private val logoutButtonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 18f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === НИЖНЯЯ ПАНЕЛЬ (СЕТАПЫ) ===
    private val setupPanelPaint = Paint().apply {
        color = MenuConfig.SETUP_PANEL_COLOR
        style = Paint.Style.FILL
    }

    private val setupPanelBorderPaint = Paint().apply {
        color = MenuConfig.BORDER_COLOR
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val setupSlotPaint = Paint().apply {
        color = MenuConfig.SETUP_SLOT_COLOR
        style = Paint.Style.FILL
    }

    private val setupSlotBorderPaint = Paint().apply {
        color = MenuConfig.SETUP_SLOT_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val setupTextPaint = Paint().apply {
        color = MenuConfig.SETUP_TEXT_COLOR
        textSize = 14f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val setupTitlePaint = Paint().apply {
        color = MenuConfig.BAR_TEXT_COLOR
        textSize = 20f
        isAntiAlias = true
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === КНОПКИ НАЦИЙ ===
    private val nationButtonPaint = Paint().apply {
        color = MenuConfig.NATION_BUTTON_COLOR
        style = Paint.Style.FILL
    }

    private val nationButtonSelectedPaint = Paint().apply {
        color = MenuConfig.NATION_BUTTON_SELECTED
        style = Paint.Style.FILL
    }

    private val nationButtonStrokePaint = Paint().apply {
        color = MenuConfig.BORDER_COLOR
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val nationTextPaint = Paint().apply {
        color = MenuConfig.NATION_BUTTON_TEXT
        textSize = 24f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private val nationTextSelectedPaint = Paint().apply {
        color = MenuConfig.NATION_BUTTON_TEXT_SELECTED
        textSize = 24f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === КНОПКА ОТКРЫТИЯ ДРЕВА ===
    private val treeButtonPaint = Paint().apply {
        color = MenuConfig.NATION_BUTTON_COLOR
        style = Paint.Style.FILL
    }

    private val treeButtonStrokePaint = Paint().apply {
        color = MenuConfig.BORDER_COLOR
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private val treeTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 30f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === СОСТОЯНИЕ ===
    private var playerName = "Игрок"
    private var playerElo = "1200"
    private var isDropdownOpen = false

    private var modeItems = listOf("ПВО", "НАЗЕМНЫЙ", "МОРСКОЙ")
    private var selectedModeIndex = 0
    private var nationItems = listOf("РОССИЯ", "США")
    private var selectedNationIndex = 0
    private var slotUnits: List<UnitData?> = listOf(null, null, null, null, null)

    private val shadowPaint = Paint().apply {
        color = Color.parseColor("#33000000")
    }

    private val highlightPaint = Paint().apply {
        color = MenuConfig.BUTTON_MODE_SELECTED
        style = Paint.Style.FILL
    }

    // === КНОПКИ ===
    data class Button(
        val rect: RectF,
        val text: String,
        val action: () -> Unit
    )

    data class ModeSection(
        val rect: RectF,
        val text: String,
        val isSelected: Boolean
    )

    data class NationButton(
        val rect: RectF,
        val text: String,
        val isSelected: Boolean
    )

    data class SetupSlot(
        val rect: RectF,
        val index: Int
    )

    private var playButton: Button? = null
    private var modeSections: List<ModeSection> = emptyList()
    private var modePanelRect: RectF? = null
    private var nationButtons: List<NationButton> = emptyList()
    private var treeButtonRect: RectF? = null
    private var setupSlots: List<SetupSlot> = emptyList()
    private var setupPanelRect: RectF? = null

    private var avatarRect: RectF? = null
    private var dropdownRect: RectF? = null
    private var logoutButtonRect: RectF? = null

    fun updateSlots(units: List<UnitData?>) {
        slotUnits = units
    }

    fun setPlayerInfo(name: String, elo: String) {
        playerName = name
        playerElo = elo
    }

    fun initialize(screenWidth: Int, screenHeight: Int) {
        val centerX = screenWidth / 2f
        val barHeight = screenHeight * MenuConfig.BAR_HEIGHT_RATIO
        val setupPanelHeight = screenHeight * MenuConfig.SETUP_PANEL_HEIGHT_RATIO

        val topBarBottom = barHeight
        val spacingFromTopBar = screenHeight * 0.02f

        // === КНОПКА ПРОФИЛЯ (под верхней плашкой, справа) ===
        val avatarSize = 56f
        val avatarMargin = 16f
        val avatarX = screenWidth - avatarSize - avatarMargin
        val avatarY = barHeight + 8f

        avatarRect = RectF(
            avatarX,
            avatarY,
            avatarX + avatarSize,
            avatarY + avatarSize
        )

        // === ВЫПАДАЮЩЕЕ МЕНЮ ===
        val dropdownWidth = 200f
        val dropdownHeight = 50f
        val dropdownX = screenWidth - dropdownWidth - avatarMargin
        val dropdownY = avatarY + avatarSize + 4f

        dropdownRect = RectF(
            dropdownX,
            dropdownY,
            dropdownX + dropdownWidth,
            dropdownY + dropdownHeight
        )

        logoutButtonRect = RectF(
            dropdownX + 12f,
            dropdownY + 6f,
            dropdownX + dropdownWidth - 12f,
            dropdownY + dropdownHeight - 6f
        )

        // === КНОПКА "ИГРАТЬ" ===
        val playButtonWidth = screenWidth * 0.28f
        val playButtonHeight = screenHeight * 0.16f
        val playButtonY = topBarBottom + spacingFromTopBar

        playButton = Button(
            rect = RectF(
                centerX - playButtonWidth / 2f,
                playButtonY,
                centerX + playButtonWidth / 2f,
                playButtonY + playButtonHeight
            ),
            text = "ИГРАТЬ",
            action = onPlayClick
        )

        // === ПАНЕЛЬ РЕЖИМОВ ===
        val modePanelWidth = screenWidth * 0.5f
        val modePanelHeight = screenHeight * 0.06f
        val spacingBetween = screenHeight * 0.015f
        val modePanelY = playButtonY + playButtonHeight + spacingBetween

        modePanelRect = RectF(
            centerX - modePanelWidth / 2f,
            modePanelY,
            centerX + modePanelWidth / 2f,
            modePanelY + modePanelHeight
        )

        val sectionWidth = modePanelWidth / modeItems.size
        modeSections = modeItems.mapIndexed { index, text ->
            ModeSection(
                rect = RectF(
                    centerX - modePanelWidth / 2f + index * sectionWidth,
                    modePanelY,
                    centerX - modePanelWidth / 2f + (index + 1) * sectionWidth,
                    modePanelY + modePanelHeight
                ),
                text = text,
                isSelected = index == selectedModeIndex
            )
        }

        // === НИЖНЯЯ ПАНЕЛЬ ===
        val setupPanelY = screenHeight - setupPanelHeight
        setupPanelRect = RectF(
            0f,
            setupPanelY,
            screenWidth.toFloat(),
            screenHeight.toFloat()
        )

        // === КНОПКИ НАЦИЙ ===
        val nationButtonWidth = screenWidth * 0.195f
        val nationButtonHeight = screenHeight * 0.0825f
        val leftPadding = screenWidth * 0.03f
        val nationY = setupPanelY - nationButtonHeight - screenHeight * 0.025f

        val treeButtonSize = nationButtonHeight
        val buttonSpacing = screenWidth * 0.02f

        treeButtonRect = RectF(
            leftPadding,
            nationY,
            leftPadding + treeButtonSize,
            nationY + treeButtonSize
        )

        nationButtons = nationItems.mapIndexed { index, text ->
            val xPos = leftPadding + treeButtonSize + buttonSpacing + index * (nationButtonWidth + buttonSpacing)
            NationButton(
                rect = RectF(
                    xPos,
                    nationY,
                    xPos + nationButtonWidth,
                    nationY + nationButtonHeight
                ),
                text = text,
                isSelected = index == selectedNationIndex
            )
        }

        // === СЛОТЫ ===
        val slotSize = setupPanelHeight * 0.6f
        val slotSpacing = screenWidth * 0.02f
        val totalSlotsWidth = slotSize * 5 + slotSpacing * 4
        val slotStartX = (screenWidth - totalSlotsWidth) / 2f
        val slotY = setupPanelY + (setupPanelHeight - slotSize) / 2f

        setupSlots = (0 until 5).map { index ->
            SetupSlot(
                rect = RectF(
                    slotStartX + index * (slotSize + slotSpacing),
                    slotY,
                    slotStartX + index * (slotSize + slotSpacing) + slotSize,
                    slotY + slotSize
                ),
                index = index
            )
        }
    }

    fun handleClick(x: Float, y: Float): Boolean {
        avatarRect?.let { rect ->
            if (rect.contains(x, y)) {
                isDropdownOpen = !isDropdownOpen
                return true
            }
        }

        if (isDropdownOpen) {
            logoutButtonRect?.let { rect ->
                if (rect.contains(x, y)) {
                    isDropdownOpen = false
                    onLogout()
                    return true
                }
            }

            dropdownRect?.let { rect ->
                if (!rect.contains(x, y)) {
                    isDropdownOpen = false
                }
            }
        }

        playButton?.let { button ->
            if (button.rect.contains(x, y)) {
                button.action()
                return true
            }
        }

        modeSections.forEachIndexed { index, section ->
            if (section.rect.contains(x, y)) {
                selectedModeIndex = index
                modeSections = modeSections.mapIndexed { i, s ->
                    s.copy(isSelected = i == selectedModeIndex)
                }
                return true
            }
        }

        treeButtonRect?.let { rect ->
            if (rect.contains(x, y)) {
                val nation = nationItems[selectedNationIndex]
                onOpenTechTree(nation)
                return true
            }
        }

        nationButtons.forEachIndexed { index, button ->
            if (button.rect.contains(x, y)) {
                selectedNationIndex = index
                nationButtons = nationButtons.mapIndexed { i, b ->
                    b.copy(isSelected = i == selectedNationIndex)
                }
                return true
            }
        }

        return false
    }

    fun draw(canvas: Canvas, screenWidth: Int, screenHeight: Int) {
        val gradientPaint = Paint().apply {
            shader = android.graphics.LinearGradient(
                0f, 0f,
                0f, screenHeight.toFloat(),
                MenuConfig.BACKGROUND_TOP,
                MenuConfig.BACKGROUND_BOTTOM,
                android.graphics.Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), screenHeight.toFloat(), gradientPaint)

        val barHeight = screenHeight * MenuConfig.BAR_HEIGHT_RATIO
        val padding = screenWidth * 0.03f
        val setupPanelHeight = screenHeight * MenuConfig.SETUP_PANEL_HEIGHT_RATIO

        // === ВЕРХНЯЯ ПАНЕЛЬ ===
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), barHeight, topBarPaint)
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), barHeight, topBarBorderPaint)

        // Реальный ник
        val nickLabel = "НИК: "
        val nickValue = playerName
        val labelWidth = topBarTextPaint.measureText(nickLabel)

        canvas.drawText(nickLabel, padding, barHeight / 2f + 6f, topBarTextPaint)
        canvas.drawText(nickValue, padding + labelWidth, barHeight / 2f + 6f, topBarBoldPaint)

        // ELO слева от аватара
        val eloLabel = " ELO: "
        val eloValue = playerElo
        val eloLabelWidth = topBarTextPaint.measureText(eloLabel)
        val eloValueWidth = topBarBoldPaint.measureText(eloValue)
        val totalWidth = eloLabelWidth + eloValueWidth
        val rightPos = screenWidth - padding - totalWidth - 70f

        canvas.drawText("ELO: ", rightPos, barHeight / 2f + 6f, topBarTextPaint)
        canvas.drawText(eloValue, rightPos + eloLabelWidth, barHeight / 2f + 6f, topBarBoldPaint)

        // === КНОПКА ПРОФИЛЯ (АВАТАР) ===
        avatarRect?.let { rect ->
            val shadowPaint2 = Paint().apply {
                color = Color.parseColor("#33000000")
            }
            canvas.drawCircle(rect.centerX() + 3f, rect.centerY() + 3f, rect.width() / 2f, shadowPaint2)

            canvas.drawCircle(rect.centerX(), rect.centerY(), rect.width() / 2f, avatarPaint)
            canvas.drawCircle(rect.centerX(), rect.centerY(), rect.width() / 2f, avatarBorderPaint)

            val firstLetter = if (playerName.isNotEmpty()) playerName[0].toString().uppercase() else "?"
            canvas.drawText(firstLetter, rect.centerX(), rect.centerY() + 10f, avatarTextPaint)
        }

        // === ВЫПАДАЮЩЕЕ МЕНЮ ===
        if (isDropdownOpen) {
            dropdownRect?.let { rect ->
                canvas.drawRoundRect(rect, 8f, 8f, dropdownBgPaint)
                canvas.drawRoundRect(rect, 8f, 8f, dropdownBorderPaint)

                logoutButtonRect?.let { btnRect ->
                    canvas.drawRoundRect(btnRect, 6f, 6f, logoutButtonPaint)
                    canvas.drawText(
                        "Выйти из аккаунта",
                        btnRect.centerX(),
                        btnRect.centerY() + 7f,
                        logoutButtonTextPaint
                    )
                }
            }
        }

        // === КНОПКА "ИГРАТЬ" ===
        playButton?.let { button ->
            canvas.drawRect(
                button.rect.left + 6f, button.rect.top + 6f,
                button.rect.right + 6f, button.rect.bottom + 6f, shadowPaint
            )
            canvas.drawRect(button.rect, playButtonPaint)
            canvas.drawRect(button.rect, playButtonStrokePaint)
            canvas.drawText(button.text, button.rect.centerX(), button.rect.centerY() + 16f, playButtonTextPaint)
        }

        // === ПАНЕЛЬ РЕЖИМОВ ===
        modePanelRect?.let { panelRect ->
            canvas.drawRoundRect(panelRect, 8f, 8f, modePanelPaint)
            canvas.drawRoundRect(panelRect, 8f, 8f, modePanelStrokePaint)

            modeSections.forEachIndexed { index, section ->
                if (index < modeSections.size - 1) {
                    val dividerX = section.rect.right
                    canvas.drawLine(
                        dividerX, section.rect.top + 6f,
                        dividerX, section.rect.bottom - 6f, modePanelStrokePaint
                    )
                }

                if (section.isSelected) {
                    canvas.drawRoundRect(
                        section.rect.left + 2f, section.rect.top + 2f,
                        section.rect.right - 2f, section.rect.bottom - 2f, 4f, 4f, highlightPaint
                    )
                }

                val paint = if (section.isSelected) modeTextSelectedPaint else modeTextPaint
                canvas.drawText(section.text, section.rect.centerX(), section.rect.centerY() + 8f, paint)
            }
        }

        // === КНОПКИ НАЦИЙ ===
        nationButtons.forEach { nation ->
            val paint = if (nation.isSelected) nationButtonSelectedPaint else nationButtonPaint
            canvas.drawRoundRect(nation.rect, 6f, 6f, paint)
            canvas.drawRoundRect(nation.rect, 6f, 6f, nationButtonStrokePaint)

            val textPaint = if (nation.isSelected) nationTextSelectedPaint else nationTextPaint
            canvas.drawText(nation.text, nation.rect.centerX(), nation.rect.centerY() + 9f, textPaint)
        }

        // === КНОПКА ОТКРЫТИЯ ДРЕВА ===
        treeButtonRect?.let { rect ->
            canvas.drawRoundRect(rect, 6f, 6f, treeButtonPaint)
            canvas.drawRoundRect(rect, 6f, 6f, treeButtonStrokePaint)
            canvas.drawText("▲", rect.centerX(), rect.centerY() + 11f, treeTextPaint)
        }

        // === НИЖНЯЯ ПАНЕЛЬ ===
        setupPanelRect?.let { panelRect ->
            canvas.drawRect(panelRect, setupPanelPaint)
            canvas.drawRect(panelRect, setupPanelBorderPaint)

            canvas.drawText(
                "ТЕХНИКА",
                screenWidth * 0.03f,
                panelRect.top + screenHeight * 0.02f + 20f,
                setupTitlePaint
            )

            setupSlots.forEach { slot ->
                val unit = slotUnits.getOrNull(slot.index)

                if (unit != null) {
                    canvas.drawRoundRect(slot.rect, 6f, 6f, setupSlotPaint)
                    canvas.drawRoundRect(slot.rect, 6f, 6f, setupSlotBorderPaint)

                    val iconPaint = Paint().apply {
                        color = Color.parseColor("#3a4050")
                        style = Paint.Style.FILL
                    }
                    val iconSize = slot.rect.width() * 0.3f
                    val centerX = slot.rect.centerX()
                    val centerY = slot.rect.centerY() - 10f
                    canvas.drawCircle(centerX, centerY, iconSize, iconPaint)

                    val iconTextPaint = Paint().apply {
                        color = Color.parseColor("#8a9aaa")
                        textSize = 18f
                        isAntiAlias = true
                        textAlign = Paint.Align.CENTER
                        typeface = Typeface.create("sans-serif", Typeface.BOLD)
                    }
                    val typeLetter = when (unit.type) {
                        UnitType.GROUND -> "Т"
                        UnitType.INFANTRY -> "П"
                        UnitType.AVIATION -> "А"
                    }
                    canvas.drawText(typeLetter, centerX, centerY + 7f, iconTextPaint)

                    val namePaint = Paint().apply {
                        color = Color.WHITE
                        textSize = 14f
                        isAntiAlias = true
                        textAlign = Paint.Align.CENTER
                        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                    }
                    canvas.drawText(unit.name, slot.rect.centerX(), slot.rect.bottom - 15f, namePaint)
                } else {
                    canvas.drawRoundRect(slot.rect, 6f, 6f, setupSlotPaint)
                    canvas.drawRoundRect(slot.rect, 6f, 6f, setupSlotBorderPaint)

                    val branchPaint = Paint().apply {
                        color = MenuConfig.SETUP_TEXT_COLOR
                        style = Paint.Style.FILL
                    }
                    val centerX = slot.rect.centerX()
                    val centerY = slot.rect.centerY()
                    val triangleSize = slot.rect.width() * 0.25f
                    val path = android.graphics.Path().apply {
                        moveTo(centerX, centerY - triangleSize)
                        lineTo(centerX - triangleSize, centerY + triangleSize * 0.5f)
                        lineTo(centerX + triangleSize, centerY + triangleSize * 0.5f)
                        close()
                    }
                    canvas.drawPath(path, branchPaint)

                    val nodePaint = Paint().apply {
                        color = MenuConfig.SETUP_SLOT_BORDER
                        style = Paint.Style.FILL
                    }
                    canvas.drawCircle(centerX, centerY, triangleSize * 0.3f, nodePaint)

                    canvas.drawText(
                        "СЛОТ ${slot.index + 1}",
                        centerX,
                        slot.rect.bottom - 15f,
                        setupTextPaint
                    )
                }
            }
        }
    }

    fun closeDropdown() {
        isDropdownOpen = false
    }
}