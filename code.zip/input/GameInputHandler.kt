package com.example.hhh.game.input

import android.view.MotionEvent
import com.example.hhh.game.entities.Player
import com.example.hhh.game.config.InputConfig
import kotlin.math.abs

class GameInputHandler(
    private val player: Player
) {
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var isTouching = false
    private var touchStartTime = 0L

    fun handleTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                isTouching = true
                touchStartTime = System.currentTimeMillis()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (isTouching) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY

                    // Двигаем игрока
                    player.move(dx, dy)

                    lastTouchX = event.x
                    lastTouchY = event.y
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                isTouching = false

                // Проверяем, был ли это клик (не свайп)
                val duration = System.currentTimeMillis() - touchStartTime
                val distance = abs(event.x - lastTouchX) + abs(event.y - lastTouchY)

                if (duration < InputConfig.MAX_TAP_DURATION && distance < InputConfig.MIN_SWIPE_DISTANCE) {
                    // Это был клик - можно использовать для стрельбы или других действий
                    handleTap(event.x, event.y)
                }
                return true
            }
        }
        return false
    }

    private fun handleTap(x: Float, y: Float) {
        // Обработка клика
        // Например, можно стрелять или ставить метку
        println("Tap at: ($x, $y)")
    }
}