package com.example.hhh.game

import android.graphics.Canvas
import android.view.SurfaceHolder
import com.example.hhh.game.config.GameConfig

class GameLoop(
    private val surfaceHolder: SurfaceHolder,
    private val gameUpdate: (Float) -> Unit,
    private val gameDraw: (Canvas) -> Unit
) {
    private var isRunning = false
    private var gameThread: Thread? = null

    private val targetFps = GameConfig.TARGET_FPS
    private val frameTime = 1000 / targetFps // ms per frame

    fun start() {
        if (isRunning) return
        isRunning = true

        gameThread = Thread {
            var lastTime = System.currentTimeMillis()

            while (isRunning) {
                val currentTime = System.currentTimeMillis()
                val deltaTime = (currentTime - lastTime) / 1000f
                lastTime = currentTime

                // Обновление
                gameUpdate(deltaTime.coerceAtMost(0.05f))

                // Отрисовка
                var canvas: Canvas? = null
                try {
                    canvas = surfaceHolder.lockCanvas()
                    if (canvas != null) {
                        gameDraw(canvas)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    if (canvas != null) {
                        try {
                            surfaceHolder.unlockCanvasAndPost(canvas)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                val elapsed = System.currentTimeMillis() - currentTime
                if (elapsed < frameTime) {
                    try {
                        Thread.sleep(frameTime - elapsed)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            }
        }
        gameThread?.start()
    }

    fun stop() {
        isRunning = false
        gameThread?.interrupt()
        gameThread = null
    }
}