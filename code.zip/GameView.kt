package com.example.hhh.game

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import com.example.hhh.game.api.ApiClient
import com.example.hhh.game.api.AuthRequest
import com.example.hhh.game.api.SaveSlotsRequest
import com.example.hhh.game.auth.TokenManager
import com.example.hhh.game.config.GameConfig
import com.example.hhh.game.config.MenuConfig
import com.example.hhh.game.config.UnitData
import com.example.hhh.game.config.UnitsConfig
import com.example.hhh.game.entities.Player
import com.example.hhh.game.hud.FpsCounter
import com.example.hhh.game.hud.GameHUD
import com.example.hhh.game.hud.HudRenderer
import com.example.hhh.game.input.GameInputHandler
import com.example.hhh.game.managers.SpawnManager
import com.example.hhh.game.screens.LoadingScreen
import com.example.hhh.game.screens.LoginScreen
import com.example.hhh.game.screens.MainMenuScreen
import com.example.hhh.game.screens.SlotSelectionScreen
import com.example.hhh.game.screens.TechTreeScreen
import com.example.hhh.game.utils.UnitTextureLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private val coroutineScope = CoroutineScope(Dispatchers.Main + Job())
    private var gameLoop: GameLoop? = null

    // Auth
    private lateinit var tokenManager: TokenManager

    // Screens
    private var loginScreen: LoginScreen? = null
    private var loadingScreen: LoadingScreen? = null
    private var mainMenuScreen: MainMenuScreen? = null
    private var techTreeScreen: TechTreeScreen? = null
    private var slotSelectionScreen: SlotSelectionScreen? = null
    private var gameScreen: GameScreen? = null

    // Game components
    private var player: Player? = null
    private var hudRenderer: HudRenderer? = null
    private var inputHandler: GameInputHandler? = null
    private var score = 0
    private var lives = 3

    // 🔥 НОВОЕ: Менеджер спавна
    private lateinit var spawnManager: SpawnManager

    private val fpsCounter = FpsCounter()
    private val gameHUD = GameHUD()
    private val slots = arrayOfNulls<UnitData>(5)
    private var playerId: String? = null

    private val inputMethodManager: InputMethodManager by lazy {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    }

    enum class GameState {
        AUTH,
        LOADING,
        MAIN_MENU,
        TECH_TREE,
        SLOT_SELECTION,
        PLAYING
    }

    private var currentState = GameState.AUTH
    private var loadingStartTime = 0L

    init {
        holder.addCallback(this)
        isFocusable = true
        isFocusableInTouchMode = true

        setOnClickListener {
            requestFocus()
        }

        tokenManager = TokenManager(context)

        if (tokenManager.isLoggedIn()) {
            currentState = GameState.MAIN_MENU
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        GameConfig.initialize(width, height)
        initScreens()

        if (currentState == GameState.AUTH) {
            loginScreen?.initialize(width, height)
        } else {
            loadingStartTime = System.currentTimeMillis()
        }

        setupHUD()

        gameLoop = GameLoop(
            surfaceHolder = holder,
            gameUpdate = { deltaTime -> update(deltaTime) },
            gameDraw = { canvas -> render(canvas) }
        )
        gameLoop?.start()
    }

    private fun setupHUD() {
        gameHUD.onUnitSelected = { unit ->
            println("🎯 Выбран юнит: ${unit.name} (${unit.type})")
            // Запускаем спавн юнита
            startSpawning(unit)
        }

        gameHUD.onTypeSelected = { typeIndex ->
            val typeName = when (typeIndex) {
                0 -> "НАЗЕМНЫЕ"
                1 -> "ПЕХОТА"
                else -> "АВИАЦИЯ"
            }
            println("📋 Выбран тип: $typeName")
        }
    }

    private fun initScreens() {
        loginScreen = LoginScreen(
            onLogin = { username, password ->
                loginToServer(username, password)
            },
            onRegister = { username, password ->
                registerOnServer(username, password)
            }
        )
        loginScreen?.initialize(width, height)

        loadingScreen = LoadingScreen()

        mainMenuScreen = MainMenuScreen(
            onPlayClick = {
                currentState = GameState.PLAYING
                initGame()
                gameScreen?.resize(width, height)
                gameHUD.updateSlots(slots.toList())
            },
            onOpenTechTree = { nation ->
                techTreeScreen?.show(nation)
                currentState = GameState.TECH_TREE
            },
            onLogout = {
                logoutFromAccount()
            }
        )
        mainMenuScreen?.initialize(width, height)

        techTreeScreen = TechTreeScreen(
            onClose = {
                currentState = GameState.MAIN_MENU
            },
            onSelectCrew = { unit ->
                slotSelectionScreen?.show(unit, slots.toList())
                currentState = GameState.SLOT_SELECTION
            }
        )
        techTreeScreen?.initialize(width, height)

        slotSelectionScreen = SlotSelectionScreen(
            onSlotSelected = { slotIndex ->
                val selectedUnit = techTreeScreen?.getSelectedUnit()
                selectedUnit?.let { unit ->
                    slots[slotIndex] = unit
                    println("✅ Установлено: ${unit.name} в слот ${slotIndex + 1}")
                    mainMenuScreen?.updateSlots(slots.toList())
                    slotSelectionScreen?.updateSlots(slots.toList())
                    gameHUD.updateSlots(slots.toList())
                    saveSlotsToServer()
                }
                currentState = GameState.TECH_TREE
            }
        )
        slotSelectionScreen?.initialize(width, height)

        gameScreen = GameScreen(context)
        gameScreen?.resize(width, height)

        // 🔥 ИНИЦИАЛИЗАЦИЯ МЕНЕДЖЕРА СПАВНА
        spawnManager = SpawnManager(context)  // ← ПЕРЕДАЕМ CONTEXT
    }

    // ============================================
    // 🔥 СПАВН ЮНИТОВ
    // ============================================

    private fun startSpawning(unit: UnitData) {
        // Проверяем, что мы в игре
        if (currentState != GameState.PLAYING) {
            Toast.makeText(context, "Сначала войдите в игру!", Toast.LENGTH_SHORT).show()
            return
        }

        spawnManager.selectUnitForSpawn(unit)
        Toast.makeText(context, "Нажмите на желтую зону спавна на карте", Toast.LENGTH_LONG).show()
    }

    private fun handleSpawnClick(x: Float, y: Float) {
        if (!spawnManager.isSpawningMode()) return

        // Получаем мировые координаты
        val worldX = gameScreen?.getWorldX(x) ?: x
        val worldY = gameScreen?.getWorldY(y) ?: y

        val spawned = spawnManager.handleMapClick(worldX, worldY)
        if (spawned) {
            Toast.makeText(context, "✅ Юнит заспавнен!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "❌ Нажмите на желтую зону спавна", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cancelSpawning() {
        if (spawnManager.isSpawningMode()) {
            spawnManager.cancelSpawning()
            Toast.makeText(context, "❌ Спавн отменен", Toast.LENGTH_SHORT).show()
        }
    }

    // ============================================
    // АУТЕНТИФИКАЦИЯ
    // ============================================

    private fun loginToServer(username: String, password: String) {
        hideKeyboard()
        loginScreen?.setLoading(true)
        loginScreen?.setError(null)

        coroutineScope.launch {
            try {
                val response = ApiClient.apiService.login(AuthRequest(username, password))

                if (response.success) {
                    tokenManager.saveSession(
                        token = response.sessionToken,
                        playerId = response.playerId,
                        playerName = response.playerName
                    )
                    playerId = response.playerId
                    loadPlayerSlots(response.slots)

                    val playerName = response.playerName
                    mainMenuScreen?.setPlayerInfo(playerName, "1200")

                    currentState = GameState.MAIN_MENU
                    loginScreen?.setLoading(false)
                    Toast.makeText(context, "Добро пожаловать, $playerName!", Toast.LENGTH_SHORT).show()

                    mainMenuScreen?.initialize(width, height)
                    mainMenuScreen?.updateSlots(slots.toList())
                } else {
                    loginScreen?.setLoading(false)
                    loginScreen?.setError(response.error ?: "Ошибка входа")
                }
            } catch (e: Exception) {
                loginScreen?.setLoading(false)
                loginScreen?.setError("Ошибка: ${e.message}")
                e.printStackTrace()
            }
        }
    }

    private fun registerOnServer(username: String, password: String) {
        hideKeyboard()
        loginScreen?.setLoading(true)
        loginScreen?.setError(null)

        coroutineScope.launch {
            try {
                val response = ApiClient.apiService.register(AuthRequest(username, password))

                if (response.success) {
                    tokenManager.saveSession(
                        token = response.sessionToken,
                        playerId = response.playerId,
                        playerName = response.playerName
                    )
                    playerId = response.playerId
                    loadPlayerSlots(response.slots)

                    val playerName = response.playerName
                    mainMenuScreen?.setPlayerInfo(playerName, "1200")

                    currentState = GameState.MAIN_MENU
                    loginScreen?.setLoading(false)
                    Toast.makeText(context, "Добро пожаловать, $playerName!", Toast.LENGTH_SHORT).show()

                    mainMenuScreen?.initialize(width, height)
                    mainMenuScreen?.updateSlots(slots.toList())
                } else {
                    loginScreen?.setLoading(false)
                    loginScreen?.setError(response.error ?: "Ошибка регистрации")
                }
            } catch (e: Exception) {
                loginScreen?.setLoading(false)
                loginScreen?.setError("Ошибка: ${e.message}")
                e.printStackTrace()
            }
        }
    }

    // ============================================
    // РАБОТА СО СЛОТАМИ
    // ============================================

    private fun loadPlayerSlots(slotIds: List<String?>) {
        slotIds.forEachIndexed { index, unitId ->
            if (unitId != null) {
                val unit = UnitsConfig.allUnits.find { it.id == unitId }
                if (unit != null) {
                    slots[index] = unit
                }
            }
        }
    }

    private fun saveSlotsToServer() {
        val username = tokenManager.getPlayerName() ?: return
        coroutineScope.launch {
            try {
                val slotIds = slots.map { it?.id }.toList()
                val response = ApiClient.apiService.saveSlots(SaveSlotsRequest(username, slotIds))
                if (!response.success) {
                    println("⚠️ Ошибка сохранения слотов: ${response.error}")
                }
            } catch (e: Exception) {
                println("⚠️ Ошибка сохранения слотов: ${e.message}")
            }
        }
    }

    // ============================================
    // ИГРА
    // ============================================

    private fun initGame() {
        val playerSize = 100f
        player = Player(
            x = (GameConfig.screenWidth / 2f) - (playerSize / 2f),
            y = (GameConfig.screenHeight / 2f) - (playerSize / 2f),
            size = playerSize
        )

        hudRenderer = HudRenderer()
        inputHandler = GameInputHandler(player!!)
        score = 0
        lives = 3

        gameScreen?.resetMap()
        gameHUD.updateSlots(slots.toList())

        // 🔥 ОБНОВЛЯЕМ СЛОТЫ ДЛЯ HUD
        updateHUDUnits()
    }

    private fun updateHUDUnits() {
        // Передаем список юнитов из слотов в HUD
        val unitList = slots.filterNotNull().toList()
        gameHUD.updateSlots(unitList.map { it })
    }

    // ============================================
    // ВЫХОД ИЗ АККАУНТА
    // ============================================

    private fun logoutFromAccount() {
        tokenManager.clear()

        slots.forEachIndexed { index, _ ->
            slots[index] = null
        }

        if (currentState == GameState.PLAYING) {
            gameLoop?.stop()
            gameScreen?.release()
        }

        currentState = GameState.AUTH
        loginScreen?.initialize(width, height)

        Toast.makeText(context, "Вы вышли из аккаунта", Toast.LENGTH_SHORT).show()
    }

    // ============================================
    // ПОКАЗ / СКРЫТИЕ КЛАВИАТУРЫ
    // ============================================

    private fun showKeyboard() {
        requestFocus()
        inputMethodManager.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        inputMethodManager.hideSoftInputFromWindow(windowToken, 0)
    }

    // ============================================
    // LIFECYCLE
    // ============================================

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        GameConfig.initialize(width, height)
        loginScreen?.initialize(width, height)
        mainMenuScreen?.initialize(width, height)
        techTreeScreen?.initialize(width, height)
        slotSelectionScreen?.initialize(width, height)
        gameScreen?.resize(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        gameLoop?.stop()
        gameScreen?.release()
        UnitTextureLoader.release()
        hideKeyboard()
    }

    fun resume() { gameLoop?.start() }
    fun pause() { gameLoop?.stop() }

    // ============================================
    // UPDATE
    // ============================================

    private fun update(deltaTime: Float) {
        fpsCounter.update(System.currentTimeMillis())

        when (currentState) {
            GameState.AUTH -> {}
            GameState.LOADING -> {
                loadingScreen?.update(System.currentTimeMillis())
                if (System.currentTimeMillis() - loadingStartTime > MenuConfig.MIN_LOADING_TIME_MS) {
                    currentState = GameState.MAIN_MENU
                }
            }
            GameState.MAIN_MENU -> {}
            GameState.TECH_TREE -> {}
            GameState.SLOT_SELECTION -> {}
            GameState.PLAYING -> {
                player?.update(deltaTime)
                gameScreen?.update(deltaTime)
                // 🔥 ОБНОВЛЯЕМ ЮНИТЫ
                spawnManager.update(deltaTime)
            }
        }
    }

    // ============================================
    // RENDER
    // ============================================

    private fun render(canvas: Canvas) {
        when (currentState) {
            GameState.AUTH -> {
                loginScreen?.draw(canvas, width, height)
            }
            GameState.LOADING -> {
                loadingScreen?.draw(canvas, width, height)
            }
            GameState.MAIN_MENU -> {
                mainMenuScreen?.draw(canvas, width, height)
            }
            GameState.TECH_TREE -> {
                mainMenuScreen?.draw(canvas, width, height)
                techTreeScreen?.draw(canvas)
            }
            GameState.SLOT_SELECTION -> {
                mainMenuScreen?.draw(canvas, width, height)
                techTreeScreen?.draw(canvas)
                slotSelectionScreen?.draw(canvas)
            }
            // com/example/hhh/game/GameView.kt
// В методе render() для состояния PLAYING:

            GameState.PLAYING -> {
                gameScreen?.draw(canvas)
                gameScreen?.let { screen ->
                    spawnManager.draw(canvas, screen)   // ← передаём gameScreen
                }
                hudRenderer?.draw(canvas, score, lives)
                gameHUD.draw(canvas, width, height)
                fpsCounter.draw(canvas)
            }
        }
    }

    // ============================================
    // TOUCH EVENTS
    // ============================================

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        val action = event.actionMasked

        when (currentState) {
            GameState.AUTH -> {
                if (action == MotionEvent.ACTION_DOWN) {
                    val handled = loginScreen?.handleClick(x, y) ?: false
                    if (handled) {
                        showKeyboard()
                    } else {
                        hideKeyboard()
                    }
                    return handled
                }
                return true
            }
            GameState.MAIN_MENU -> {
                if (action == MotionEvent.ACTION_DOWN) {
                    hideKeyboard()
                    return mainMenuScreen?.handleClick(x, y) ?: false
                }
                return true
            }
            GameState.TECH_TREE -> {
                if (action == MotionEvent.ACTION_DOWN) {
                    if (techTreeScreen?.handleClick(x, y) == true) {
                        return true
                    }
                }
                return techTreeScreen?.handleTouch(event) ?: false
            }
            GameState.SLOT_SELECTION -> {
                if (action == MotionEvent.ACTION_DOWN) {
                    return slotSelectionScreen?.handleClick(x, y) ?: false
                }
                return true
            }
            GameState.PLAYING -> {
                // 🔥 ВАЖНО: для мультитач (зум) нужно пропускать события с несколькими пальцами
                if (event.pointerCount > 1) {
                    // Передаем в карту для зума
                    return gameScreen?.handleTouch(event) ?: false
                }

                if (action == MotionEvent.ACTION_DOWN) {
                    // 1. Проверяем HUD
                    if (gameHUD.handleClick(x, y)) {
                        return true
                    }

                    // 2. Проверяем режим спавна
                    if (spawnManager.isSpawningMode()) {
                        handleSpawnClick(x, y)
                        return true
                    }

                    // 3. Передаем в карту (панорамирование)
                    return gameScreen?.handleTouch(event) ?: false
                }

                // 4. Для MOVE и UP тоже передаем в карту
                return gameScreen?.handleTouch(event) ?: false
            }
            else -> {
                return true
            }
        }
    }

    // ============================================
    // KEY EVENTS
    // ============================================

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (currentState == GameState.AUTH) {
            val keyChar = event?.unicodeChar?.toChar()

            if (keyChar != null && keyChar.isLetterOrDigit()) {
                loginScreen?.handleKey(keyChar)
                return true
            }

            when (keyCode) {
                KeyEvent.KEYCODE_DEL -> {
                    loginScreen?.handleKey('\b')
                    return true
                }
                KeyEvent.KEYCODE_ENTER -> {
                    loginScreen?.handleKey('\n')
                    val username = loginScreen?.getUsername() ?: ""
                    val password = loginScreen?.getPassword() ?: ""
                    val isLoginMode = loginScreen?.isLoginMode() ?: true

                    if (username.isNotBlank() && password.isNotBlank()) {
                        if (isLoginMode) {
                            loginToServer(username, password)
                        } else {
                            registerOnServer(username, password)
                        }
                    }
                    return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    // Отмена спавна по кнопке "Назад"
                    if (currentState == GameState.PLAYING && spawnManager.isSpawningMode()) {
                        cancelSpawning()
                        return true
                    }
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}