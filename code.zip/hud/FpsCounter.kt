package com.example.hhh.game.hud

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface

class FpsCounter {
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = true
        typeface = Typeface.create("monospace", Typeface.BOLD)
        textAlign = Paint.Align.LEFT
    }

    private val bgPaint = Paint().apply {
        color = Color.parseColor("#88000000")
        style = Paint.Style.FILL
    }

    private var frameCount = 0
    private var lastFpsUpdateTime = 0L
    private var currentFps = 0

    fun update(currentTime: Long) {
        frameCount++
        if (currentTime - lastFpsUpdateTime >= 1000) {
            currentFps = frameCount
            frameCount = 0
            lastFpsUpdateTime = currentTime
        }
    }

    fun draw(canvas: Canvas) {
        val text = "FPS: $currentFps"
        val textWidth = textPaint.measureText(text)
        val padding = 12f
        val height = 40f
        val x = 16f
        val y = 16f

        // Фон
        canvas.drawRoundRect(
            x, y,
            x + textWidth + padding * 2,
            y + height,
            8f, 8f, bgPaint
        )

        // Текст
        canvas.drawText(
            text,
            x + padding,
            y + height / 2f + textPaint.textSize / 2f - 4f,
            textPaint
        )
    }
}