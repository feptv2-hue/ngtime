package com.example.hhh.game.hud

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.hhh.game.config.UnitData
import com.example.hhh.game.config.UnitType

class GameHUD {
    // === КНОПКА ОТКРЫТИЯ МЕНЮ ===
    private val menuButtonPaint = Paint().apply {
        color = Color.parseColor("#88aaaaaa")  // Серый, слегка прозрачный
        style = Paint.Style.FILL
    }

    private val menuButtonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 32f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // === КНОПКИ ВЫБОРА ТИПА ===
    private val typeButtonPaint = Paint().apply {
        color = Color.parseColor("#88aaaaaa")
        style = Paint.Style.FILL
    }

    private val typeButtonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 22f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    // === КНОПКИ ЮНИТОВ ===
    private val unitButtonPaint = Paint().apply {
        color = Color.parseColor("#88bbbbbb")
        style = Paint.Style.FILL
    }

    private val unitButtonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 18f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    // === КНОПКА ЗАКРЫТИЯ МЕНЮ (ВРЕМЕННО) ===
    private val closeButtonPaint = Paint().apply {
        color = Color.parseColor("#88ff4444")
        style = Paint.Style.FILL
    }

    private val closeButtonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 20f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    // Состояние
    private var isMenuOpen = false
    private var selectedTypeIndex = 0  // 0 - наземные, 1 - пехота, 2 - авиация

    // Данные слотов
    private var slotUnits: List<UnitData?> = listOf(null, null, null, null, null)

    // Позиции кнопок
    private var menuButtonRect: RectF? = null
    private var typeButtons: List<RectF> = emptyList()
    private var unitButtons: List<RectF> = emptyList()
    private var closeButtonRect: RectF? = null

    // Callbacks
    var onUnitSelected: ((UnitData) -> Unit)? = null
    var onTypeSelected: ((Int) -> Unit)? = null

    fun updateSlots(units: List<UnitData?>) {
        slotUnits = units
    }

    fun handleClick(x: Float, y: Float): Boolean {
        // Кнопка открытия/закрытия меню
        menuButtonRect?.let { rect ->
            if (rect.contains(x, y)) {
                isMenuOpen = !isMenuOpen
                if (!isMenuOpen) {
                    // При закрытии сбрасываем выбор типа
                    selectedTypeIndex = 0
                }
                return true
            }
        }

        if (!isMenuOpen) return false

        // Кнопки выбора типа (1, 2, 3)
        typeButtons.forEachIndexed { index, rect ->
            if (rect.contains(x, y)) {
                selectedTypeIndex = index
                onTypeSelected?.invoke(index)
                return true
            }
        }

        // Кнопки юнитов
        unitButtons.forEach { rect ->
            if (rect.contains(x, y)) {
                // Находим юнит по позиции кнопки
                val unitIndex = unitButtons.indexOf(rect)
                val unit = getUnitsForType(selectedTypeIndex).getOrNull(unitIndex)
                unit?.let {
                    onUnitSelected?.invoke(it)
                    return true
                }
            }
        }

        return false
    }

    private fun getUnitsForType(typeIndex: Int): List<UnitData> {
        val type = when (typeIndex) {
            0 -> UnitType.GROUND
            1 -> UnitType.INFANTRY
            else -> UnitType.AVIATION
        }
        return slotUnits.filterNotNull().filter { it.type == type }
    }

    fun draw(canvas: Canvas, screenWidth: Int, screenHeight: Int) {
        val buttonWidth = 60f
        val buttonHeight = 50f
        val padding = 8f
        val topOffset = 80f
        val leftOffset = 10f

        // === КНОПКА ОТКРЫТИЯ ===
        val menuX = leftOffset
        val menuY = topOffset

        val menuRect = RectF(menuX, menuY, menuX + buttonWidth, menuY + buttonHeight)
        menuButtonRect = menuRect

        // Рисуем основную кнопку
        canvas.drawRect(menuRect, menuButtonPaint)

        // Рисуем текст [>] или [<]
        val text = if (isMenuOpen) "<" else ">"
        canvas.drawText(text, menuRect.centerX(), menuRect.centerY() + 11f, menuButtonTextPaint)

        if (isMenuOpen) {
            // === КНОПКИ ВЫБОРА ТИПА (1, 2, 3) ===
            val typeButtonWidth = 50f
            val typeButtonHeight = 45f
            val typeStartX = menuRect.right + padding
            val typeY = menuY

            val typeLabels = listOf("1", "2", "3")
            val tempTypeButtons = mutableListOf<RectF>()

            typeLabels.forEachIndexed { index, label ->
                val x = typeStartX + index * (typeButtonWidth + padding)
                val rect = RectF(x, typeY, x + typeButtonWidth, typeY + typeButtonHeight)
                tempTypeButtons.add(rect)

                // Подсветка выбранного типа
                val paint = if (selectedTypeIndex == index) {
                    Paint().apply {
                        color = Color.parseColor("#ccaaaaaa")
                        style = Paint.Style.FILL
                    }
                } else {
                    typeButtonPaint
                }

                canvas.drawRect(rect, paint)
                canvas.drawText(label, rect.centerX(), rect.centerY() + 8f, typeButtonTextPaint)
            }
            typeButtons = tempTypeButtons

            // === ЮНИТЫ ВЫБРАННОГО ТИПА ===
            val units = getUnitsForType(selectedTypeIndex)
            val unitButtonWidth = 120f
            val unitButtonHeight = 40f
            val unitStartX = typeStartX
            val unitY = typeY + typeButtonHeight + padding

            val tempUnitButtons = mutableListOf<RectF>()

            units.forEachIndexed { index, unit ->
                val x = unitStartX + index * (unitButtonWidth + padding)
                val rect = RectF(x, unitY, x + unitButtonWidth, unitY + unitButtonHeight)
                tempUnitButtons.add(rect)

                canvas.drawRect(rect, unitButtonPaint)

                // Сокращаем имя если слишком длинное
                var displayName = unit.name
                if (displayName.length > 12) {
                    displayName = displayName.take(10) + ".."
                }
                canvas.drawText(displayName, rect.centerX(), rect.centerY() + 7f, unitButtonTextPaint)
            }
            unitButtons = tempUnitButtons
        }
    }
}