package com.example.hhh.game.hud

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.example.hhh.game.config.GameConfig
import com.example.hhh.game.config.HudConfig

class HudRenderer {
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 40f
        isAntiAlias = true
    }

    private val backgroundPaint = Paint().apply {
        color = Color.argb(180, 0, 0, 0)
    }

    fun draw(canvas: Canvas, score: Int, lives: Int) {
        // Фон для HUD (полупрозрачная полоса сверху)
        canvas.drawRect(
            0f, 0f,
            GameConfig.screenWidth.toFloat(), 60f,
            backgroundPaint
        )

        // Отображение счета
        canvas.drawText(
            "Score: $score",
            GameConfig.screenWidth * 0.05f,
            45f,
            textPaint
        )

        // Отображение жизней
        canvas.drawText(
            "Lives: $lives",
            GameConfig.screenWidth * 0.85f,
            45f,
            textPaint
        )
    }
}