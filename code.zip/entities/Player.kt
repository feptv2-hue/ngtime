package com.example.hhh.game.entities

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.example.hhh.game.config.GameConfig

class Player(
    x: Float,
    y: Float,
    private val size: Float
) : GameObject() {

    private val paint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    init {
        this.x = x
        this.y = y
        this.width = size
        this.height = size
    }

    fun move(dx: Float, dy: Float) {
        val newX = x + dx
        val newY = y + dy

        // Ограничение движения в пределах экрана
        x = newX.coerceIn(0f, GameConfig.screenWidth - width)
        y = newY.coerceIn(0f, GameConfig.screenHeight - height)
    }

    override fun update(deltaTime: Float) {
        // Обновление игрока
        // Можно добавить анимации или другие эффекты
    }

    override fun draw(canvas: Canvas) {
        // Рисуем квадрат с обводкой
        canvas.drawRect(x, y, x + width, y + height, paint)
        canvas.drawRect(x, y, x + width, y + height, borderPaint)
    }
}