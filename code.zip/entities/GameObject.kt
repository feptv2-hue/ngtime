package com.example.hhh.game.entities

import android.graphics.Canvas
import android.graphics.Rect

abstract class GameObject {
    var x: Float = 0f
    var y: Float = 0f
    var width: Float = 0f
    var height: Float = 0f
    var isActive: Boolean = true

    abstract fun update(deltaTime: Float)
    abstract fun draw(canvas: Canvas)

    fun getBounds(): Rect {
        return Rect(
            x.toInt(),
            y.toInt(),
            (x + width).toInt(),
            (y + height).toInt()
        )
    }

    fun containsPoint(px: Float, py: Float): Boolean {
        return px >= x && px <= x + width &&
                py >= y && py <= y + height
    }
}