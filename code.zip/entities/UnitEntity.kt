// com/example/hhh/game/entities/UnitEntity.kt
package com.example.hhh.game.entities

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.example.hhh.game.GameScreen
import com.example.hhh.game.config.UnitData
import com.example.hhh.game.config.UnitStats
import com.example.hhh.game.utils.UnitTextureLoader
import kotlin.math.cos
import kotlin.math.sin

class UnitEntity(
    val data: UnitData,
    val stats: UnitStats,
    startX: Float,
    startY: Float
) : GameObject() {

    init {
        x = startX
        y = startY
        width = data.width
        height = data.height
        isActive = true
    }

    var angle: Float = 0f
    var turretAngle: Float = 0f
    var targetX: Float = startX
    var targetY: Float = startY
    var isMoving: Boolean = false

    var corpusTexture: Bitmap? = null
    var turretTexture: Bitmap? = null

    // Отладочные Paint'ы
    private val debugFillPaint = Paint().apply {
        color = Color.parseColor("#33FF0000")
        style = Paint.Style.FILL
    }

    private val debugBorderPaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val debugHitboxPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val positionPaint = Paint().apply {
        color = Color.YELLOW
        style = Paint.Style.FILL
    }

    fun loadTextures(context: Context) {
        println("📂 Загрузка текстуры корпуса: ${data.textureCorpus}")
        corpusTexture = UnitTextureLoader.loadTexture(context, data.textureCorpus)

        if (data.textureTurret.isNotEmpty()) {
            println("📂 Загрузка текстуры башни: ${data.textureTurret}")
            turretTexture = UnitTextureLoader.loadTexture(context, data.textureTurret)
        }

        if (corpusTexture == null) {
            println("❌ КОРПУС НЕ ЗАГРУЖЕН! Проверь путь: ${data.textureCorpus}")
        }
    }

    fun moveTo(targetX: Float, targetY: Float) {
        this.targetX = targetX
        this.targetY = targetY
        isMoving = true
    }

    fun stopMoving() {
        isMoving = false
    }

    override fun update(deltaTime: Float) {
        if (!isMoving || !isActive) return

        val dx = targetX - x
        val dy = targetY - y
        val distance = kotlin.math.sqrt(dx * dx + dy * dy)

        if (distance < 5f) {
            x = targetX
            y = targetY
            isMoving = false
            return
        }

        val targetAngle = kotlin.math.atan2(dy, dx) * 180f / Math.PI.toFloat()
        var angleDiff = targetAngle - angle

        if (angleDiff > 180) angleDiff -= 360f
        if (angleDiff < -180) angleDiff += 360f

        val maxRotation = data.rotationSpeed * deltaTime
        angle += when {
            kotlin.math.abs(angleDiff) < maxRotation -> angleDiff
            angleDiff > 0 -> maxRotation
            else -> -maxRotation
        }

        turretAngle = angle

        val speed = data.speed * deltaTime
        val rad = angle * Math.PI.toFloat() / 180f
        x += speed * cos(rad)
        y += speed * sin(rad)
    }

    fun draw(canvas: Canvas, gameScreen: GameScreen) {
        if (!isActive) return

        val zoom = gameScreen.getZoom()
        val cx = gameScreen.getScreenX(x)
        val cy = gameScreen.getScreenY(y)

        // 🔥 РАЗМЕР НА КАРТЕ С УЧЕТОМ ЗУМА
        val halfW = (width / 2f) * zoom
        val halfH = (height / 2f) * zoom

        // ============================================
        // ОТЛАДОЧНЫЕ КВАДРАТЫ
        // ============================================

        canvas.drawCircle(cx, cy, 5f * zoom, positionPaint)

        canvas.drawRect(
            cx - halfW,
            cy - halfH,
            cx + halfW,
            cy + halfH,
            debugFillPaint
        )
        canvas.drawRect(
            cx - halfW,
            cy - halfH,
            cx + halfW,
            cy + halfH,
            debugBorderPaint
        )

        val hw = (data.hitboxWidth / 2f) * zoom
        val hh = (data.hitboxHeight / 2f) * zoom
        canvas.drawRect(
            cx - hw,
            cy - hh,
            cx + hw,
            cy + hh,
            debugHitboxPaint
        )

        // ============================================
        // 🔥 РИСУЕМ КОРПУС
        // ============================================
        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(angle)

        corpusTexture?.let { bmp ->
            val texW = bmp.width.toFloat()
            val texH = bmp.height.toFloat()

            // 🔥 МАСШТАБ КОРПУСА С УЧЕТОМ ЗУМА
            val scaleX = (width * zoom) / texW
            val scaleY = (height * zoom) / texH

            val left = -data.pivotX * scaleX
            val top = -data.pivotY * scaleY
            val right = (texW - data.pivotX) * scaleX
            val bottom = (texH - data.pivotY) * scaleY

            val dst = RectF(left, top, right, bottom)
            canvas.drawBitmap(bmp, null, dst, null)
        } ?: run {
            val crossPaint = Paint().apply {
                color = Color.WHITE
                strokeWidth = 2f * zoom
                style = Paint.Style.STROKE
            }
            canvas.drawLine(-halfW, -halfH, halfW, halfH, crossPaint)
            canvas.drawLine(-halfW, halfH, halfW, -halfH, crossPaint)

            val textPaint = Paint().apply {
                color = Color.WHITE
                textSize = 12f * zoom
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(data.name, 0f, 0f, textPaint)
        }

        canvas.restore()

        // ============================================
        // 🔥 РИСУЕМ БАШНЮ
        // ============================================
        turretTexture?.let { bmp ->
            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(turretAngle)

            val texW = bmp.width.toFloat()
            val texH = bmp.height.toFloat()

            // 🔥 МАСШТАБ БАШНИ С УЧЕТОМ ЗУМА
            val turretW = data.turretWidth * zoom
            val turretH = data.turretHeight * zoom

            val scaleX = turretW / texW
            val scaleY = turretH / texH

            val left = -data.turretPivotX * scaleX
            val top = -data.turretPivotY * scaleY
            val right = (texW - data.turretPivotX) * scaleX
            val bottom = (texH - data.turretPivotY) * scaleY

            val dst = RectF(left, top, right, bottom)
            canvas.drawBitmap(bmp, null, dst, null)

            canvas.restore()
        }

        // ============================================
        // ИНФОРМАЦИЯ О ЮНИТЕ
        // ============================================
        drawUnitInfo(canvas, cx, cy, zoom)
    }

    private fun drawUnitInfo(canvas: Canvas, cx: Float, cy: Float, zoom: Float) {
        val infoPaint = Paint().apply {
            color = Color.WHITE
            textSize = 14f * zoom
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = android.graphics.Typeface.create("monospace", android.graphics.Typeface.BOLD)
        }

        val bgPaint = Paint().apply {
            color = Color.parseColor("#CC000000")
            style = Paint.Style.FILL
        }

        val infoText = "${data.name} (${String.format("%.0f", x)}, ${String.format("%.0f", y)})"
        val textWidth = infoPaint.measureText(infoText)
        val padding = 8f * zoom
        val height = 30f * zoom
        val yPos = cy - height / 2 - 10f * zoom

        canvas.drawRoundRect(
            cx - textWidth/2 - padding,
            yPos - height/2,
            cx + textWidth/2 + padding,
            yPos + height/2,
            4f * zoom, 4f * zoom, bgPaint
        )

        canvas.drawText(infoText, cx, yPos + 5f * zoom, infoPaint)
    }

    fun hitTest(px: Float, py: Float): Boolean {
        val hw = data.hitboxWidth / 2f
        val hh = data.hitboxHeight / 2f
        return px >= x - hw && px <= x + hw &&
                py >= y - hh && py <= y + hh
    }

    fun getHitbox(): RectF {
        val hw = data.hitboxWidth / 2f
        val hh = data.hitboxHeight / 2f
        return RectF(x - hw, y - hh, x + hw, y + hh)
    }

    override fun draw(canvas: Canvas) {
        // Пустой метод для совместимости с GameObject
    }
}