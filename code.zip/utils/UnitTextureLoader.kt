// com/example/hhh/game/utils/UnitTextureLoader.kt
package com.example.hhh.game.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

object UnitTextureLoader {

    private val textureCache = mutableMapOf<String, Bitmap>()

    /**
     * Загрузить текстуру из assets
     * @param context Контекст
     * @param path Путь в папке assets (например, "textures/units/russia/t72/corpus.png")
     * @return Bitmap или null, если не загрузилось
     */
    fun loadTexture(context: Context, path: String): Bitmap? {
        // Проверяем кэш
        textureCache[path]?.let {
            println("✅ Текстура из кэша: $path")
            return it
        }

        return try {
            val inputStream = context.assets.open(path)
            val options = BitmapFactory.Options().apply {
                inScaled = false  // Не масштабировать
            }
            val bitmap = BitmapFactory.decodeStream(inputStream, null, options)
            inputStream.close()

            if (bitmap != null) {
                textureCache[path] = bitmap
                println("✅ Загружена текстура: $path (${bitmap.width}x${bitmap.height})")
            } else {
                println("❌ Не удалось декодировать: $path")
            }
            bitmap
        } catch (e: Exception) {
            println("❌ Ошибка загрузки текстуры: $path - ${e.message}")
            null
        }
    }

    /**
     * Освободить память
     */
    fun release() {
        textureCache.values.forEach {
            try { it.recycle() } catch (_: Exception) {}
        }
        textureCache.clear()
        println("🧹 Текстуры освобождены")
    }
}