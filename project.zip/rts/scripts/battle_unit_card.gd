extends TextureButton # Если корневой узел TextureButton. Если обычная кнопка, напиши extends Button

# Переменная, которая временно сохранит имя танка
var unit_name_to_display: String = ""

# Функция, которую вызывает игровой мир сразу после создания плашки
func setup_card(incoming_name: String) -> void:
	unit_name_to_display = incoming_name
	# К этому моменту узел уже добавлен в дерево (add_child вызывается раньше),
	# так что _ready() уже отработал — ставим текст прямо тут, а не ждём _ready().
	_apply_name()

# Встроенная функция Godot. Срабатывает АВТОМАТИЧЕСКИ, когда кнопка
# физически появляется в дереве сцены и её дочерний Label точно загружен в память!
func _ready() -> void:
	# На случай, если setup_card() вызовут ДО добавления в дерево — подстрахуемся и тут.
	_apply_name()

func _apply_name() -> void:
	if has_node("UnitName") and unit_name_to_display != "":
		get_node("UnitName").text = unit_name_to_display
