extends Camera2D

# Настройки чувствительности управления
@export var zoom_speed: float = 0.05
@export var min_zoom: float = 0.5
@export var max_zoom: float = 2.5

# Переменные для отслеживания тачей на телефоне
var touch_events: Dictionary = {}
var start_zoom: Vector2
var start_distance: float = 0.0

# Переменная для отслеживания зажатия мыши на ПК
var is_dragging_mouse: bool = false

func _unhandled_input(event: InputEvent) -> void:
		# --- ЗУМ КОЛЕСИКОМ МЫШИ ДЛЯ ТЕСТОВ НА ПК ---
	if event is InputEventMouseButton:
		# Если крутим колесико ВВЕРХ — приближаем камеру
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			var target_zoom = zoom + Vector2(zoom_speed, zoom_speed)
			zoom.x = clamp(target_zoom.x, min_zoom, max_zoom)
			zoom.y = clamp(target_zoom.y, min_zoom, max_zoom)
			
		# Если крутим колесико ВНИЗ — отдаляем камеру
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			var target_zoom = zoom - Vector2(zoom_speed, zoom_speed)
			zoom.x = clamp(target_zoom.x, min_zoom, max_zoom)
			zoom.y = clamp(target_zoom.y, min_zoom, max_zoom)

	# --- ЧАСТЬ 1: УНИВЕРСАЛЬНЫЙ СВАЙП КАРТЫ (ПК + СМАРТФОН) ---
	
	# Ловим зажатие/отпускание левой кнопки мыши на ПК
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		is_dragging_mouse = event.pressed
		
	# Если мышь зажата и движется — двигаем камеру
	if event is InputEventMouseMotion and is_dragging_mouse:
		# Перемещаем камеру вслед за курсором (с учетом текущего зума)
		position -= event.relative / zoom.x


	# --- ЧАСТЬ 2: МОБИЛЬНЫЙ МУЛЬТИТАЧ (ЗУМ ПАЛЬЦАМИ НА СМАРТФОНЕ) ---
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_events[event.index] = event
		else:
			touch_events.erase(event.index)
			
		if touch_events.size() == 2:
			var fingers = touch_events.values()
			start_distance = fingers[0].position.distance_to(fingers[1].position)
			start_zoom = zoom

	elif event is InputEventScreenDrag:
		touch_events[event.index] = event
		
		# Если на телефоне зажато 2 пальца — делаем Pinch-to-Zoom
		if touch_events.size() == 2:
			var fingers = touch_events.values()
			var current_distance = fingers[0].position.distance_to(fingers[1].position)
			
			if start_distance > 0:
				var factor = current_distance / start_distance
				var target_zoom = start_zoom * factor
				
				target_zoom.x = clamp(target_zoom.x, min_zoom, max_zoom)
				target_zoom.y = clamp(target_zoom.y, min_zoom, max_zoom)
				zoom = target_zoom
