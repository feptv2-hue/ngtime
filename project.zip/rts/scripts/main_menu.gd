extends Node2D

# Ссылки на наш новый HUD интерфейс
@onready var battle_slots_container: HBoxContainer = $CanvasLayer/UnitSpawnPanel/BattleSlotsContainer
@onready var camera: Camera2D = $Camera2D

# Загружаем шаблон танка (создавали на прошлом шаге)
var tank_scene = preload("res://scenes/tank.tscn")

# Переменная помнит, какая вкладка HUD сейчас открыта ("GROUND" или "HELI")
var current_hud_category: String = "GROUND"

func _ready() -> void:
	print("Матч начался! Загружаем HUD деки...")
	# При старте игры по умолчанию показываем только наземные юниты
	refresh_spawn_hud("GROUND")


# Функция очищает нижнюю панель и заново создает только нужные кнопки юнитов под категорию
func refresh_spawn_hud(category: String) -> void:
	# 1. Сначала удаляем старые кнопки, чтобы они не дублировались
	for child in battle_slots_container.get_children():
		child.queue_free()
		
	# Ждем один кадр, чтобы Godot физически удалил старые узлы из памяти
	await get_tree().process_frame
	
	# Достаем синглтон через безопасный путь /root
	var global = get_node("/root/GlobalData")
	if not global:
		print("Ошибка: GlobalData не найден!")
		return
		
	# 2. Пробегаемся по нашей сохраненной деке из главного меню
	for unit_name in global.current_deck:
		if unit_name == "":
			continue
			
		# Проверяем по ключевым словам в названии, вертолет это или танк
		var is_heli = "Ка-52" in unit_name or "Ми-28" in unit_name or "Apache" in unit_name or "Viper" in unit_name
		
		# Фильтруем: пропускаем ненужное под текущую вкладку
		if category == "GROUND" and is_heli:
			continue 
		if category == "HELI" and not is_heli:
			continue 
			
		# 3. Создаем кнопку вызова техники прямо из кода!
		var new_btn = Button.new()
		new_btn.text = unit_name
		new_btn.custom_minimum_size = Vector2(140, 100) # Размер плашки юнита в бою
		
		# Если в проекте есть шрифт Oswald, применяем его
		if ResourceLoader.exists("res://assets/fonts/Oswald-Bold.ttf"):
			var font = load("res://assets/fonts/Oswald-Bold.ttf")
			new_btn.add_theme_font_override("font", font)
			
		# Связываем клик по плашке с физическим спавном танка на карте
		new_btn.pressed.connect(func(): spawn_unit(unit_name))
		
		# Выводим готовую плашку на нижнюю панель экрана
		battle_slots_container.add_child(new_btn)
		print("Добавлен в HUD боя: ", unit_name)


# --- ОБРАБОТКА НАЖАТИЙ НА ЛЕВЫЕ КНОПКИ КАТЕГОРИЙ ---

func _on_ground_cat_button_pressed() -> void:
	current_hud_category = "GROUND"
	refresh_spawn_hud("GROUND")

func _on_heli_cat_button_pressed() -> void:
	current_hud_category = "HELI"
	refresh_spawn_hud("HELI")


# --- СПАВН ЮНИТА ПО ЦЕНТРУ КАМЕРЫ ---
func spawn_unit(unit_type: String) -> void:
	print("Вызываем на поле боя: ", unit_type)
	var new_unit = tank_scene.instantiate()
	# Ставим танк ровно туда, куда сейчас смотрит камера игрока
	new_unit.position = camera.position
	add_child(new_unit)
