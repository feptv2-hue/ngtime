extends TextureButton

# @export выносит переменную прямо в Инспектор справа!
# Сюда мы будем писать уникальное имя для каждого танка прямо в редакторе.
@export var unit_name: String = "Т-90М"

# Ссылка на текст внутри плашки
@onready var label: Label = $UnitName

func _ready() -> void:
	# При старте игры автоматически пишем имя танка на плашке
	if label:
		label.text = unit_name


# Сама карточка ловит клик по себе
func _pressed() -> void:
	# Передаем имя этого конкретного танка в главное меню
	# owner — это корневой узел сцены (наш MainMenu)
	if owner and owner.has_method("select_unit_for_deck"):
		owner.select_unit_for_deck(unit_name)
