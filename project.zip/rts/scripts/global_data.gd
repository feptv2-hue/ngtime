extends Node

# Массив, который хранит нашу деку из 6 слотов
var current_deck: Array = ["", "", "", "", "", ""]
