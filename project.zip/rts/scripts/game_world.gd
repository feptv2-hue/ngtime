extends Node2D

# Ссылки на твой HUD
@onready var battle_slots_container: HBoxContainer = $CanvasLayer/UnitSpawnPanel/BattleSlotsContainer
@onready var camera: Camera2D = $Camera2D

# Прелаб самого танка для спавна на траве
var tank_scene = preload("res://scenes/tank.tscn")

# ЗАГРУЖАЕМ твою отдельную кастомную сцену плашки!
var battle_card_scene = preload("res://scenes/battle_unit_card.tscn")

func _ready() -> void:
	print("Матч начался! Загружаем HUD боевого интерфейса...")
	
	# Принудительно заставляем HBoxContainer центровать элементы
	if battle_slots_container:
		battle_slots_container.alignment = BoxContainer.ALIGNMENT_CENTER
		
	# При старте матча сразу инициализируем и показываем наземку
	refresh_spawn_hud("GROUND")


func refresh_spawn_hud(category: String) -> void:
	print("Обновляем HUD для категории: ", category)
	
	# 1. Полностью очищаем контейнер от старых кнопок
	for child in battle_slots_container.get_children():
		child.queue_free()
		
	# Ждем один игровой кадр, чтобы Godot физически удалил старые узлы из памяти
	await get_tree().process_frame
	
	# Достаем наш синглтон через безопасный прямой путь /root
	var global = get_node("/root/GlobalData")
	if not global:
		print("Ошибка: Глобальный синглтон GlobalData не найден в системе!")
		return
		
	print("Текущая дека в памяти синглтона: ", global.current_deck)
	
	# 2. Пробегаемся по сохраненной деке
	for unit_name in global.current_deck:
		# ИГНОРИРУЕМ пустые строки и заглушки
		if unit_name == "" or unit_name == "Пусто" or unit_name == "[ Пусто ]":
			continue 
			
		# Проверка класса техники (вертолет или танк)
		var is_heli: bool = "Ка-" in unit_name or "Ми-" in unit_name or "AH-" in unit_name
		
		# Фильтруем боевой HUD под текущую открытую вкладку
		if category == "GROUND" and is_heli:
			continue 
		if category == "HELI" and not is_heli:
			continue 
			
		# 3. СПАВНИМ ТВОЮ КАСТОМНУЮ КНОПКУ ИЗ СЦЕНЫ
		var new_card = battle_card_scene.instantiate()
		
		# Сначала обязательно добавляем её в контейнер, чтобы она ожила
		battle_slots_container.add_child(new_card)
		
		# Передаем ей имя техники (функция _ready внутри плашки сама запишет текст)
		new_card.setup_card(unit_name)
		
		# Связываем сигнал нажатия на твою кастомную кнопку со спавном юнита
		new_card.pressed.connect(func(): spawn_unit(unit_name))
		
		print("Успешно выведена кастомная плашка из сцены: ", unit_name)


# --- СИГНАЛЫ ПЕРЕКЛЮЧЕНИЯ ВКЛАДОК ЛЕВОЙ ПАНЕЛИ ---

func _on_ground_cat_button_pressed() -> void:
	refresh_spawn_hud("GROUND")

func _on_heli_cat_button_pressed() -> void:
	refresh_spawn_hud("HELI")


# --- ФУНКЦИЯ СПАВНА ЮНИТА НА КАРТЕ ТРАВЫ ---
func spawn_unit(unit_type: String) -> void:
	print("Вызываем на поле боя физический юнит: ", unit_type)
	if tank_scene:
		var new_unit = tank_scene.instantiate()
		new_unit.position = camera.position
		add_child(new_unit)
